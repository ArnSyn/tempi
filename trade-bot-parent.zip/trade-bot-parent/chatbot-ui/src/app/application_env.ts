
export const environments: any[] = [
    //set the prod evn and url - http://34.249.35.24
    {
        name: "production",
        url: 'https://finlabs-aiml.synechron.net/',
        state: false
    },
    //set the staging evn and url - http://34.248.34.18
    {
        name: "staging",
        url: 'https://aiml-staging.synechron.net/',
        state: false
    },
    //set the staging evn and url
    {
        name: "local1",
        url: 'http://172.22.52.23:83/',
        state: false
    },
    //set the staging evn and url
    {
        name: "local2",
        url: 'http://172.22.52.23:8080/trade-bot/',
        state: false
    },
    //set the Docker evn and url
    {
        name: "docker",
        url: '/trade-bot/rest/',
        state: true
    }
];

