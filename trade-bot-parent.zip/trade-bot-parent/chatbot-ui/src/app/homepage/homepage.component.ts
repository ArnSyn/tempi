import { Component } from '@angular/core';
import { routerTransition } from './../router.animations';

@Component({
  selector: 'homepage',
  templateUrl: './homepage.html',
  animations: [routerTransition()],
  host: {'[@routerTransition]': ''}
})
export class HomepageComponent {
  
}
