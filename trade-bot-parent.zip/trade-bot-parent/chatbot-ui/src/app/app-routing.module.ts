import { NgModule }             from '@angular/core';
import { Routes } from '@angular/router';
import { RegistrationComponent } from './registration/registration.component';
import { HomepageComponent } from './homepage/homepage.component';
import { LoginComponent } from './login/login.component';
import { AccRegistrationComponent } from './account-registration/account-registration.component';
import { ChatComponent } from './chat-window/chat-window.component';
import { ChatItemComponent } from './chat-window/dynamic-component';
import { AuthGuard } from './authentication/index';

export const routes: Routes = [
  
  { path: 'homepage',  component: HomepageComponent },
  { path: 'register',  component: RegistrationComponent },  
  { path: 'login',  component: LoginComponent },  
  { path: 'acc-register',  component: AccRegistrationComponent , canActivate: [AuthGuard] }, 
  { path: 'chat-window',  component: ChatComponent, canActivate: [AuthGuard] },
  { path: 'check', component: ChatItemComponent},
  { path: '**', redirectTo: 'chat-window' }

];

