import { Component, ViewChild } from '@angular/core';
import { GoogleMapsAPIWrapper } from 'angular2-google-maps/core/services';
import * as mapTypes from 'angular2-google-maps/core/services/google-maps-types';
import { Router,ActivatedRoute} from '@angular/router';
import { RegistrationService } from '../registration/registration.service';
import { routerTransition } from './../router.animations';

declare var google: any;

@Component({
  selector: 'account-registration',
  providers: [GoogleMapsAPIWrapper,RegistrationService],
  templateUrl: './account-registration.html',
  styleUrls: ['account-registration.css'],
  animations: [routerTransition()],
  host: {'[@routerTransition]': ''}
})


export class AccRegistrationComponent {

  private regData: any = {
    status:1,   
    gender:"",
    property:"",
    familyStatus:"",
    income: 0,
    age: 0,
    fullAddress:"",
    partnerAge:0,
    partnerIncome:0,
    partnerChildren: 0,
    investmentAmt: 0,
  }


  private activatedRouteSub: any;
  address1: string = '';
  address2: string = '';

  marker: any;
  ageConfig: any = {
    connect: "lower",
    start: [0],
    keyboard: true,  // same as [keyboard]="true"
    step: 1,  // number of page steps, defaults to 10
    range: {
      min: 0,
      max: 100
    }

  };
  incomeConfig: any = {
    connect: "lower",
    start: [0],
    keyboard: true,  // same as [keyboard]="true"
    step: 1,  // number of page steps, defaults to 10
    range: {
      min: 0,
      max: 100000
    }

  };
  investmentConfig: any = {
    connect: "lower",
    start: [0],
    keyboard: true,  // same as [keyboard]="true"
    step: 1,  // number of page steps, defaults to 10
    range: {
      min: 0,
      max: 10000
    }

  };
  childrenConfig: any = {
    connect: "lower",
    start: [0],
    keyboard: true,  // same as [keyboard]="true"
    step: 1,  // number of page steps, defaults to 10
    range: {
      min: 0,
      max: 10
    }

  };
  lat: number = 51.678418;
  lng: number = 7.809007;
  locationShow: boolean = false;
  isBtnDisabled: boolean= true;



  constructor(private _mapsWrapper: GoogleMapsAPIWrapper, private router : Router, private activatedRoute: ActivatedRoute, private registrationService: RegistrationService) {
    _mapsWrapper.getNativeMap().then((m: mapTypes.GoogleMap) => {

    });
  }

  getGeoLocation(lat: number, lng: number) {

    if (navigator.geolocation) {

      let latlng = new google.maps.LatLng(lat, lng);
      let geocoder = new google.maps.Geocoder();
      let request = { latLng: latlng };

      geocoder.geocode(request, (results, status) => {
        if (status == google.maps.GeocoderStatus.OK) {
          let result = results[0];
          let rsltAdrComponent = result.address_components;
          let resultLength = rsltAdrComponent.length;
          if (result != null) {
            this.address1 = '';
            this.address2 = '';
            for (let i = 0; i < resultLength; i++) {
              if (rsltAdrComponent[i].short_name) {
                if (this.address1.length > 50) {
                  this.address2 = this.address2 + rsltAdrComponent[i].short_name;
                  if (i != resultLength - 1) {
                    this.address2 = this.address2 + ', ';
                  }
                } else {
                  this.address1 = this.address1 + rsltAdrComponent[i].short_name;
                  if (i != resultLength - 1) {
                    this.address1 = this.address1 + ', ';
                  }
                }
              }
            }

          } 
        }
      });
    }
  }

  markerDragEnd(event) {

    this.lat = event.coords.lat;
    this.lng = event.coords.lng;
    this.getGeoLocation(this.lat, this.lng);
  }

  genderSelection(selection) {
    this.regData.gender = selection;
    this.isBtnDisabled=false;
  }

   familyStatusSelection(selection) {
    this.regData.familyStatus = selection;
    this.isBtnDisabled = false;
  }

  propertySelection(selection) {
    this.regData.property = selection;
    this.isBtnDisabled=false;
  }

  activeSlideCount: number = 0;

  buttonTrigger() {
    this.isBtnDisabled = true;
    this.activeSlideCount = $('div.active').index() + 1;
  }
   buttonTriggerVlaue(value) {
     this.isBtnDisabled = true;
     this.activeSlideCount = value;
   }
  
  saveProfile(){
  let userData =JSON.parse(localStorage.getItem('tradebot-currentUser'));
  
  this.regData.fullAddress = this.address1+ this.address2;
  this.registrationService.saveProfile(this.regData, userData.customerId).subscribe(
          data => {
             let userData = JSON.parse(localStorage.getItem('tradebot-currentUser'));
             userData.regData= this.regData;
             localStorage.setItem('tradebot-currentUser',JSON.stringify(userData));
              this.router.navigate(['/chat-window']);   
          },
         error => {
           this.router.navigate(['/login']); 
          });
    // To do - Register user service call
   
    

  }

  checkProfileInfo(regData: any){
    if(regData.gender==""){
      this.buttonTriggerVlaue(0);
      return false;
    }else if(regData.age ==""){
      this.buttonTriggerVlaue(1)
      return false;
    }else if(regData.income == 0){
      this.buttonTriggerVlaue(2)
      return false;
    }else if(regData.familyStatus == ""){
      this.buttonTriggerVlaue(3)
      return false;
    }else if(regData.partnerAge == 0  ){
      this.buttonTriggerVlaue(4)
      return false;
    }else if(regData.property == ""){
      this.buttonTriggerVlaue(5)
      return false;
    }else if(regData.fullAddress == ""){
      this.buttonTriggerVlaue(6)
      return false;
    }else if(regData.investmentAmt == 0){
      this.buttonTriggerVlaue(7)
      return false;
    }
    return true;
  }

setPosition(position){
   this.lat = position.coords.latitude;
  this.lng = position.coords.longitude;
  
}
   ngOnInit() {
    this.activatedRouteSub = this.activatedRoute
      .queryParams
      .subscribe(params => {
         let userData = JSON.parse(localStorage.getItem('tradebot-currentUser'));
         if(params['returnUrl'] == '/login' || params['returnUrl'] == '/chat-window'){
          if(typeof userData.regData != 'undefined'){
           this.regData = userData.regData;
           this.checkProfileInfo(this.regData)
          }
         }
      });

      if(navigator.geolocation){
      navigator.geolocation.getCurrentPosition(this.setPosition.bind(this));
      };
  }

  ngOnDestroy() {
    this.activatedRouteSub.unsubscribe();
  }


}

