import { Component, ComponentFactoryResolver, ViewContainerRef } from '@angular/core';
import { AddChatComponent } from './add-chat.component';

@Component({
    selector: 'chat-item',
    template: `
               
    `
})
export class ChatItemComponent {
    constructor(private componentFactoryResolver: ComponentFactoryResolver,
        private viewContainerRef: ViewContainerRef) {
    }

    public sayHello() {
        const factory = this.componentFactoryResolver.resolveComponentFactory(AddChatComponent);
        const ref = this.viewContainerRef.createComponent(factory);
        ref.changeDetectorRef.detectChanges();
    }
}