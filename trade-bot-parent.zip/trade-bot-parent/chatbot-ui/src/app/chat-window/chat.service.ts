
import { Injectable } from '@angular/core';

import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import { environments } from '../application_env';

@Injectable()
export class ChatService {

    private url;  // URL to web API
    public static userMessage: string;
    public static botMessage: string;
    public static chartData: any = null;
    public static botTableData: any = null;
    public static responseType: string;
    public static botImage: string;
    public static botSuggestion: any = null;
    constructor(private http: Http) { }

    getEnvironment() {
        for (let i = 0; i < environments.length; i++) {
            if (environments[i].state) {
                return environments[i].url;
            }
        }
    }

    clearSessionInBot(): Observable<any>{
         let userData = JSON.parse(localStorage.getItem('tradebot-currentUser'));
         this.url = this.getEnvironment() + 'clear?customerId='+userData.customerId;
         return this.http.get(this.url)
            .map(res=>{
               let body = res.json();
                return body || {};
            })
            .catch(this.handleError);
    }
    getResponseFromBot(question:string): Observable<any> {
        let userData = JSON.parse(localStorage.getItem('tradebot-currentUser'));
       this.url = this.getEnvironment() + 'trade?customerId='+userData.customerId+'&q='+question;
       return this.http.get(this.url)
            .map(this.extractData)
            .catch(this.handleError);
      //  ChatService.botMessage = 'Hello from service am here botMessage !..'
       // return 'Hello from service !am here..';

    }

    postQuery(message:string){
        ChatService.userMessage = message;
        return ChatService.userMessage;
    }
    
    private extractData(res: Response) {
        
        let body = res.json();
        ChatService.userMessage = "";
        ChatService.botMessage = body.message;
        if(body.responseType == 'image'){
            ChatService.responseType = 'image';
            ChatService.botImage =body.message;
       }else if(body.data && body.responseType == 'table'  &&body.data.portfolioDetails){
            ChatService.responseType = 'portfolio';
            ChatService.botTableData = body.data.portfolioDetails;
            ChatService.chartData = {
                totalChange: body.data.totalChange,
                totalCurrentValue:body.data.totalCurrentValue,
                totalInvestedValue:body.data.totalCurrentValue
            }
        }
        else if(body.data && body.responseType == 'table' && body.data.watctList){
              ChatService.responseType = 'watchlist';
              ChatService.botTableData = body.data.watctList;
        }
       if(body && body.suggestions){
            ChatService.botSuggestion = body.suggestions;
        }
        return body || {};
    }
    private handleError(error: Response | any) {
        // In a real world app, we might use a remote logging infrastructure
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error(errMsg);
        return Observable.throw(errMsg);
    }

    logout(){
        // remove user from local storage to log user out
        localStorage.removeItem('tradebot-currentUser');
    }
}
