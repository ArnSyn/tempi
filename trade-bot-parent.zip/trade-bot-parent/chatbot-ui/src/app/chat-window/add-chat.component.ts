import { Component, AfterViewInit, ViewContainerRef,ComponentFactoryResolver, ViewChild, ElementRef } from '@angular/core';
import { ChatService } from './chat.service';
import { Chart } from 'angular-highcharts';

@Component({
    selector: 'chat-element',
    providers: [ChatService],
    template: `
        <div class="chatelementsection" #chatelementsection>
    
         <div *ngIf="myChatText" class="mymessage">
          <span class="bubbleright">{{myChatText}}</span>
        <p><img class="" src="/trade-bot/assets/double-tick-indicator.png"><span class="chattimeright"> {{today | date:'hh:mm a'}}</span></p> 
        </div>
        <div *ngIf="botChatText" class="botmessage">
            <span  *ngIf="botChatText && !responseType" class="bubbleleft">{{botChatText}}</span>
           
    <!-- Start: Showing response for portfolio -->
            <div *ngIf="responseType == 'portfolio'" class="bubblelefttable"   >
            <div class="chart" [chart]="chart"></div>
            <table class="table">
                <thead>
                    <tr>
                        <th style="width:10%">Stock</th>
                        <th>Qty</th>
                        <th>Hold Price</th>
                        <th>Current Price</th>
                        <th>Total Gain</th>
                        <th>Today’s Gain</th>
                    </tr>
                </thead>
                <tbody>
                    <tr *ngFor="let item of botTableData">
                        <td style="width:10%">{{item.stockname}}</td>
                        <td>{{item.quantity}}</td>
                        <td> {{item.holdPrice}}</td>
                        <td>{{item.currentPrice}}</td>
                        <td>{{item.overallGain | number : '1.2-3'}}<i *ngIf="item.overallGain > 0" class="fa fa-arrow-up icon-uparrow" aria-hidden="true"></i><i *ngIf="item.overallGain < 0" class="fa fa-arrow-down icon-downarrow" aria-hidden="true"></i></td>
                        <td>{{item.todaysGain | number : '1.2-3'}}<i *ngIf="item.todaysGain > 0" class="fa fa-arrow-up icon-uparrow" aria-hidden="true"></i><i *ngIf="item.todaysGain < 0" class="fa fa-arrow-down icon-downarrow" aria-hidden="true"></i></td>

                    </tr>
                </tbody>
            </table>
          </div>
    <!-- End: Showing response for portfolio -->

    <!-- Start: Showing response for watchlist -->
        <div *ngIf="responseType == 'watchlist'" class="bubblelefttable" >
          <table class="table">
                <thead>
                    <tr>
                        <th style="width:10%">Company</th>
                        <th>Stock </th>
                        <th>Current Price</th>
                        <th>High</th>
                        <th>Low</th>
                        <th>Today’s Gain</th>
                    </tr>
                </thead>
                <tbody>
                    <tr *ngFor="let item of botTableData">
                        <td style="width:10%">{{item.stockName}}</td>
                        <td>{{item.stockId}}</td>
                        <td> {{item.currentPrice}}</td>
                        <td>{{item.todaysHigh}}</td>
                        <td>{{item.todaysLow}}</td>
                        <td>{{item.todaysGain | number : '1.2-3'}}<i *ngIf="item.todaysGain > 0" class="fa fa-arrow-up icon-uparrow" aria-hidden="true"></i><i *ngIf="item.todaysGain < 0" class="fa fa-arrow-down icon-downarrow" aria-hidden="true"></i></td>

                    </tr>
                </tbody>
            </table>
          </div>
    <!-- END: Showing response for watchlist -->

    <!-- Start: Showing response for images -->
          <div  *ngIf="responseType == 'image'"  class="bubblelefttable">
            <img [src]="'data:image/jpg;base64,'+botImage" class="bubbleleftimage"/> 
        </div>
    <!-- End: Showing response for images -->
     <div *ngIf="botSuggestion" >
                <p class="suggestionbtn" *ngFor="let entry of botSuggestion | SugesstionExtractor" (click)="suggestionSelect(entry.value)" >{{entry.key}}</p>
          </div>
         <p class="chattimeleft">{{today | date:'hh:mm a'}}</p>
        </div>
        

        </div>
        
    `,
     styles: [],
    styleUrls: ['chat-window.css']
})
export class AddChatComponent implements AfterViewInit {
    private botChatText: string;
    private myChatText: string;
    private chart :any;
    private responseType:string;
    private chartData :any;
    private botTableData :any;
    private botSuggestion :any;
    private botImage: string;
    private el: ElementRef;
    private today: number = Date.now();
    constructor(private chatService : ChatService,private componentFactoryResolver: ComponentFactoryResolver,
        private viewContainerRef: ViewContainerRef,el: ElementRef) {
            this.el = el; 
    }
 @ViewChild('triggerBotBtn') triggerBot: ElementRef;

   suggestionSelect(value) {
      this.chatService.getResponseFromBot(value).subscribe(
          data => {
             this.invokeRenderer();
            this.scrollToBottom();
                  },
         error => {
             console.log(error)
          });
    }

    invokeRenderer(){
        const factory = this.componentFactoryResolver.resolveComponentFactory(AddChatComponent);
        const ref = this.viewContainerRef.createComponent(factory);
        ref.changeDetectorRef.detectChanges();   
    }
    ngAfterViewInit(): void {
       this.myChatText = ChatService.userMessage;
        this.botChatText = ChatService.botMessage;
        this.chartData = ChatService.chartData
        this.botTableData = ChatService.botTableData;
        this.responseType = ChatService.responseType;
        this.botImage = ChatService.botImage;
        this.botSuggestion = ChatService.botSuggestion;
        if( this.chartData){
          this.chart = new Chart({
           	chart: {
           		type: 'column',
           		height: 200,
           		width: null
           	},
           	title: {
           		text: ''
           	},
           	xAxis: {
           		categories: ['Portfolio'],
                title:null
           	},
            yAxis:{
                title:null
            },
           	credits: {
           		enabled: false
           	},
            tooltip: {
                enabled:false
            },
           	legend: {
           		align: 'right',
           		verticalAlign: 'middle',
           		layout: 'vertical',
           		itemStyle: {
           			fontSize: '1em',
           			fontWeight: 'normal'
           		},
                lineHeight:23,
           		symbolRadius: 6,
           		symbolWidth: 12,
                labelFormatter: function () {
                     return this.name;
                }
           	},
           	plotOptions: {
           		series: {
           			animation: {
           				duration: 200,
           				easing: 'easeOutBounce'
           			}
           		}
           	},
           	series: [{
           		data: [this.chartData.totalInvestedValue],
           		name: '<span style=" opacity: 0.6;">Total Invested</span> <br><strong> $'+this.chartData.totalInvestedValue +'</strong>',
           		color: '#D07070'
           	}, {
           		data: [this.chartData.totalCurrentValue],
           		name: ' <span style=" opacity: 0.6;">Current Value</span> <br><strong>$'+this.chartData.totalCurrentValue +'</strong>',
           		color: '#1b998b'
           	}, {
           		data: [this.chartData.totalChange],
           		name: '<span style=" opacity: 0.6;">Total Change</span> <br> <strong>$'+this.chartData.totalChange +'</strong>',
           		color: '#5992C4'
           	}]
           });
        }

        ChatService.botMessage = '';
        ChatService.chartData = null;
        ChatService.botTableData = null;
        ChatService.responseType='';
        ChatService.botImage='';
        ChatService.botSuggestion = null;
        this.scrollToBottom();
 
    }
    
    scrollToBottom(): void {
    setTimeout(()=>{
             const hostElem = this.el.nativeElement;
            hostElem.parentNode.scrollTop = hostElem.parentNode.scrollHeight
                   }, 0);
            
    }
     
}