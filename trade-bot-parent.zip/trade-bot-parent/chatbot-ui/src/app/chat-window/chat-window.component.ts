import { Component, ViewChild, ElementRef, Renderer, Input, OnDestroy,HostListener } from '@angular/core';
import { SpeechRecognitionService } from './speech-recognition.service';
import { ChatService } from './chat.service';
import { ChatItemComponent } from './dynamic-component';
import { routerTransition } from './../router.animations';

@Component({
  selector: 'chat-window',
  providers: [ChatService, SpeechRecognitionService],
  templateUrl: './chat-window.html',
  styleUrls: ['chat-window.css'],
  animations: [routerTransition()],
  host: {'[@routerTransition]': ''}
})

export class ChatComponent {
  constructor(private chatService: ChatService,
    private renderer: Renderer,
    private speechRecognitionService: SpeechRecognitionService) {
  }

  ngOnDestroy() {
   this.speechRecognitionService.DestroySpeechObject();
  }
  query: string;
  isRecording: boolean;
  isSearching:boolean;
  showSearchButton: boolean;
  showProfileButton:boolean;

  @Input()
  chatItem: ChatItemComponent;

  @ViewChild('triggerBotBtn') triggerBot: ElementRef;
  @ViewChild('chatwindow') chatwindow: ElementRef;
  
  checkQuery(){
      if (this.query.length > 0) {
          this.showSearchButton=true;
      }else{
        this.showSearchButton=false;
      }
  }
  
  submitquery() {
    if (this.query.length > 0) {
      this.query = this.query.trim();
      this.chatService.postQuery(this.query);
      this.isSearching = true;
      this.showSearchButton = false;
      //this.triggerBot.sayHello();
      let event = new MouseEvent('click', { bubbles: true });
      this.renderer.invokeElementMethod(
      this.triggerBot.nativeElement, 'dispatchEvent', [event]);
      this.chatService.getResponseFromBot(this.query).subscribe(
          data => {
                   this.isSearching = false;;
                   let event = new MouseEvent('click', { bubbles: true });
                   this.renderer.invokeElementMethod(
                   this.triggerBot.nativeElement, 'dispatchEvent', [event]);
                  
                  },
         error => {
             console.log(error)
          });
      this.query = '';
    }
  }

  clearSession() {
    this.chatService.clearSessionInBot().subscribe(
          data => {
                  this.clearScreen();
                  },
         error => {
             console.log(error)
          });
  }

  clearScreen() {
    $('chat-element').html('');
  }

  logout() {
    this.chatService.logout();
  }
   openKeyBoard(){
     let mobiledevice = this.isMobile();
   if(mobiledevice){
    document.getElementById("chatwindow").style.height = "50%";
   }
  }

  closeKeyBoard(){
    document.getElementById("chatinput").style.top = "0px";
    document.getElementById("chatwindow").style.height = "86%";
  }

  isMobile() {
  try{ document.createEvent("TouchEvent"); return true; }
  catch(e){ return false; }
}

  speechData: any;


  activateSpeechInput(): void {
    this.showSearchButton = false;

    if (this.isRecording) {
      this.speechRecognitionService.record()
        .subscribe(

        //listener
        (value) => {
          this.speechData = value;
          this.query = this.speechData;
          this.submitquery();
        },
        //errror
        (err) => {
          console.log(err);
          if (err.error == "no-speech") {
            console.log("--restatring service--");
            this.activateSpeechInput();
          }
        },
        //completion
        () => {
          this.showSearchButton = true;
          console.log("--complete--");
          this.activateSpeechInput();
        });
    }
  }

  stopSpeechInput() {
    this.speechRecognitionService.DestroySpeechObject();
    this.isRecording = false;
  }
  ngOnInit(){
       let userData = JSON.parse(localStorage.getItem('tradebot-currentUser'));
       let regData = userData.regData;
       if(typeof regData == "undefined" || regData.gender=="" || regData.age =="" || regData.income == 0 || regData.familyStatus == "" ||
                  regData.partnerAge == 0 || regData.property == "" || regData.fullAddress == "" || regData.investmentAmt == 0){
                   this.showProfileButton=true;
              }
  }
  


}

