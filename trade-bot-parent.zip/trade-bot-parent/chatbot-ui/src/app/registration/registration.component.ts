import { Component } from '@angular/core';
import { Router} from '@angular/router';
import { RegistrationService } from './registration.service';
import { routerTransition } from './../router.animations';

@Component({
  selector: 'registration',
  templateUrl: './registration.html',
  providers : [RegistrationService],
  animations: [routerTransition()],
  host: {'[@routerTransition]': ''}

})
export class RegistrationComponent {
  userName : string;
  password : string;
  errorMessage : string;

  constructor( private router : Router, private registrationService: RegistrationService){
  }

   register() {
    if (this.userName && this.userName.length > 0 && this.password && this.password.length > 0) {
      this.registrationService.register(this.userName, this.password).subscribe(
          data => {
            if(data.status == 'failed'){
               this.errorMessage = data.message;
            }else{
              var user : any = {};
            user.username = this.userName;
            user.password = this.password;
            user.customerId=data.customerId;
            localStorage.setItem('tradebot-currentUser', JSON.stringify(user));
            this.router.navigate(['/acc-register']);
            }
          },
         error => {
           this.errorMessage = error;
          });
    }
    else {
      this.errorMessage = 'Please enter Username and password !..';
    }
  }

  removeMsg() {
    this.errorMessage = '';
  }
}