import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'
import { environments } from '../application_env';

@Injectable()
export class RegistrationService {
  
    constructor(private http: Http) { }

 getEnvironment() {
        for (let i = 0; i < environments.length; i++) {
            if (environments[i].state) {
                return environments[i].url;
            }
        }
    }
    register(username: string, password: string) {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let body = {
            "username":username,
            "password":password
        }
        let options = new RequestOptions({ headers: headers });
        let bodyString = JSON.stringify(body);
        return this.http.post(this.getEnvironment()+'signup?username='+username+'&password='+password, bodyString, options)
            .map(this.extractData)
            .catch(this.resgisterError);   
    }


    private extractData(res: Response) {
        let body = res.json();
        return body || {};
    }

    private resgisterError(error: Response | any) {
        let errMsg: string = 'Please try with valid Credentials.';
        return Observable.throw(errMsg);
    }

    saveProfile(regData:any,customerId: string) {
        let bodyString = JSON.stringify(regData);
        return this.http.post(this.getEnvironment()+'saveprofile?customerId='+customerId, bodyString)
            .map(res =>{
                  let body = res.text();
                    return body || {};
            }).catch(this.saveProfileError);
           
    }
    
    private saveProfileError(error: Response | any) {
       let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        return Observable.throw(errMsg);
    }

}