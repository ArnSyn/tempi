import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from "@angular/router";
import { routes } from './app-routing.module';
import { NouisliderModule } from 'ng2-nouislider';
import { AgmCoreModule } from 'angular2-google-maps/core';
import * as $ from 'jquery';
import { AuthGuard } from './authentication/index';
import { ChartModule } from 'angular-highcharts';
import { AppComponent } from './app.component';
import { HomepageComponent } from './homepage/homepage.component';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';
import { AccRegistrationComponent } from './account-registration/account-registration.component';
import { ChatComponent } from './chat-window/chat-window.component';
import { ChatItemComponent } from './chat-window/dynamic-component';
import {  AddChatComponent } from './chat-window/add-chat.component';
import {  SugesstionExtractorPipe } from './chat-window/sugesstion-key-extractor.pipe'  

@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
    RegistrationComponent,
    LoginComponent,
    AccRegistrationComponent,
    ChatComponent,
    ChatItemComponent,
    AddChatComponent,
    SugesstionExtractorPipe
  ],
  entryComponents: [AddChatComponent],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    ChartModule,
    RouterModule.forRoot(routes, { useHash: true }),
    NouisliderModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyAQtwtLzDItVwUjmfQJ2MkpivObpV2ZZ_I'
    })
  ],
  providers: [AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
