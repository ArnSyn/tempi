import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from './login.service';
import { routerTransition } from './../router.animations';

@Component({
  selector: 'login',
  templateUrl: './login.html',
  providers : [LoginService],
  animations: [routerTransition()],
  host: {'[@routerTransition]': ''}

})
export class LoginComponent {
  userName: string;
  password: string;
  errorMessage: string;
  private sub: any;
  constructor(private router: Router, private loginService: LoginService) {
  }

  login() {
    if (this.userName && this.userName.length > 0 && this.password && this.password.length > 0) {
      this.loginService.login(this.userName, this.password).subscribe(
          data => {
              if(data.status == 'failed'){
                this.errorMessage = data.message;
              }else{
                var user : any = {};
              user.username = this.userName;
              user.password = this.password;
              user.customerId=data.customerId;
              let regData = data.data;
              delete regData['_id'];
              user.regData=data.data;
              localStorage.setItem('tradebot-currentUser', JSON.stringify(user));
              if(typeof regData == "undefined" || regData.gender=="" || regData.age =="" || regData.income == 0 || regData.familyStatus == "" ||
                  regData.partnerAge == 0 || regData.property == "" || regData.fullAddress == "" || regData.investmentAmt == 0){
                    //localStorage.setItem('register-tradebot-currentUser', JSON.stringify(user));
                   this.router.navigate(['/acc-register'], { queryParams: { returnUrl: '/login'}});
              }
              else{
                    this.router.navigate(['/chat-window']);
                }
            }
          },
         error => {
           this.errorMessage = error;
          });
      
    }
    else {
      this.errorMessage = 'Please enter Username and password !..';
    }
  }

  removeMsg() {
    this.errorMessage = '';
  }
 
  
}

