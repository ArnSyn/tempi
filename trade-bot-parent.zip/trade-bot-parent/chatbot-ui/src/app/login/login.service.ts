import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions  } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'
import { environments } from '../application_env';

@Injectable()
export class LoginService {
  constructor(private http: Http) { }

 getEnvironment() {
        for (let i = 0; i < environments.length; i++) {
            if (environments[i].state) {
                return environments[i].url;
            }
        }
    }

    login(username: string, password: string):Observable<any> {
       let headers = new Headers({ 'Content-Type': 'application/json' });
        let body = {
            "username":username,
            "password":password
        }
        let options = new RequestOptions({ headers: headers });
        let bodyString = JSON.stringify(body);
        return this.http.post(this.getEnvironment()+'signin?username='+username+'&password='+password, bodyString, options)
            .map(this.extractData)
            .catch(this.handleError);
    }

    private extractData(res: Response) {
        let body = res.json();
        return body || {};

    }
    private handleError(error: Response | any) {
        // In a real world app, we might use a remote logging infrastructure
        let errMsg: string = 'Please try with valid Credentials.';
        return Observable.throw(errMsg);
    }


}