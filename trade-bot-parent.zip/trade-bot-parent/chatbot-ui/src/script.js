
$(document).ready(function () {
    $('body').click(function (evt) {
        
        if (evt.target.id == "optionsmenuicon") {
            if ($('#popup-menu').css('display') == 'none') {
                $('#popup-menu').css("display", "block");
            } else {
                $('#popup-menu').css("display", "none");
            }
        } else {
            if ($('#popup-menu').css('display') == 'block') {
                $('#popup-menu').css("display", "none");
            }
        }
        //maximize();
        
    });

function maximize(){
    var docElm = document.documentElement;

    if (docElm.requestFullscreen) {
    docElm.requestFullscreen();
    }

    else if (docElm.mozRequestFullScreen) {
    docElm.mozRequestFullScreen();          
    }

    else if (docElm.webkitRequestFullScreen) {
    docElm.webkitRequestFullScreen(); 
    }   
}
    
});