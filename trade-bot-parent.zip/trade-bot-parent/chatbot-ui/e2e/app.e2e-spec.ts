import { TraderBotPage } from './app.po';

describe('trader-bot App', () => {
  let page: TraderBotPage;

  beforeEach(() => {
    page = new TraderBotPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
