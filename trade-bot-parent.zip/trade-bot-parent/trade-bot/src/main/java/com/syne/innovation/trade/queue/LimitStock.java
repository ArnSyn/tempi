package com.syne.innovation.trade.queue;

import java.io.Serializable;
import java.math.BigDecimal;

public class LimitStock implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String symbol;
	private BigDecimal limitPrice;
	private int customerId;
	private int numberOfStocks;
	
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public BigDecimal getLimitPrice() {
		return limitPrice;
	}
	public void setLimitPrice(BigDecimal limitPrice) {
		this.limitPrice = limitPrice;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getNumberOfStocks() {
		return numberOfStocks;
	}
	public void setNumberOfStocks(int numberOfStocks) {
		this.numberOfStocks = numberOfStocks;
	}
}
