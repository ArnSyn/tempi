package com.syne.innovation.trade.service;

public interface TradeFlow {

	// Processes every statement sent by user and returns the response.
	public String processChat(String request, int customerId);

	public String clearCurrentSession(int customerId);

	public String isCustomerPresent(int customerId);
	
	public String signUp(String username, String password);

	public String isCustomerPresent(String username, String password);

	public String saveSignUpData(int customerId, String profileData);
	
}
