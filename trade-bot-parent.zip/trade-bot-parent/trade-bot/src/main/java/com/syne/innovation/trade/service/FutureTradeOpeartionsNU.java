package com.syne.innovation.trade.service;

import java.math.BigDecimal;

import javax.jms.JMSException;

public interface FutureTradeOpeartionsNU {

	public String doTransaction(boolean isBuy, String symbol, int quantity, BigDecimal price, int customerId) throws JMSException;
}
