package com.syne.innovation.trade.service;

import static com.mongodb.client.model.Filters.eq;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.transaction.Transactional;

import org.bson.Document;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.mongodb.client.MongoCursor;
import com.syne.innovation.trade.constants.CommonConstants;
import com.syne.innovation.trade.exception.TradeException;
import com.syne.innovation.trade.nlp.NlpService;
import com.syne.innovation.trade.persistence.dao.GenericDao;
import com.syne.innovation.trade.persistence.dao.MongoDao;
import com.syne.innovation.trade.persistence.entity.BankAccount;
import com.syne.innovation.trade.persistence.entity.ChatDetails;
import com.syne.innovation.trade.persistence.entity.ChatHistory;
import com.syne.innovation.trade.persistence.entity.CurrentProblem;
import com.syne.innovation.trade.persistence.entity.Customer;
import com.syne.innovation.trade.persistence.entity.LoginCredentials;
import com.syne.innovation.trade.persistence.entity.Portfolio;
import com.syne.innovation.trade.persistence.entity.PortfolioDetails;
import com.syne.innovation.trade.vo.BotResponse;
import com.syne.innovation.trade.vo.Entity;
import com.syne.innovation.trade.vo.LuisResponse;
import com.syne.innovation.trade.vo.VisiblePortfolio;
import com.syne.innovation.trade.vo.VisiblePortfolioDetails;
import com.syne.innovation.trade.vo.VisibleWatchList;

import yahoofinance.Stock;
import yahoofinance.quotes.fx.FxQuote;

/*
 * This class gets requests from end user, understands the intent behind each request, processes them and responds accordingly.
 * Different methods are provided to support various kind of requests.
 */
@Component
public class TradeFlowImpl implements TradeFlow {

	@Autowired
	private NlpService nlpService;

	@Autowired
	private GenericDao<Customer, Integer> customerDao;

	@Autowired
	private GenericDao<BankAccount, Integer> bankAccountDao;
	
	@Autowired
	private GenericDao<LoginCredentials, Integer> loginCredentialsDao;

	@Autowired
	private MongoDao mongoDao;

	@Autowired
	private TradeOperations tradeOperations;

	private Properties commodityProperties = new Properties();
	
	private Properties companyProperties = new Properties();

	@PostConstruct
	public void readProperties() throws IOException {
		InputStream input = this.getClass().getClassLoader().getResourceAsStream("commodities.properties");
		commodityProperties.load(input);
		
		input = this.getClass().getClassLoader().getResourceAsStream("companies.properties");
		companyProperties.load(input);
	}

	// Method to process a request sent.
	@Override
	public String processChat(String request, int customerId) {
		try {
			Date queriedOn = new Date();
			ChatDetails chatDetails = getChatByCustomer(customerId);
			LuisResponse luisResponse = nlpService.parseSentence(request);

			String bestIntent = luisResponse.getBestIntent().getIntent();
			System.out.println("Intent received : " + bestIntent);
			String response = "";

			if (luisResponse.getBestIntent().getIntent().equalsIgnoreCase("positive")
					|| luisResponse.getBestIntent().getIntent().equalsIgnoreCase("negative")) {
				// Reload last chat
				Collections.sort(chatDetails.getChatHistory());
				if (luisResponse.getBestIntent().getIntent().equalsIgnoreCase("positive")) {
					// Move all the temp entities into
					// actual entities object.
					chatDetails.getCurrentProblem().getEntities()
							.putAll(chatDetails.getChatHistory().get(0).getTempEntities());
				} else if (!luisResponse.getBestIntent().getIntent().equalsIgnoreCase("negative")) {
					// Move the current chat to failed_chats collection.
					Collections.sort(chatDetails.getChatHistory());
					mongoDao.save(chatDetails.getChatHistory().get(0).getDocument(),
							CommonConstants.FAILED_CHATS_COLLECTION);
					// Clear the current chat, update chat_details and reply
					// with a sorry message starting chat afresh.
					chatDetails.setCurrentProblem(null);
					chatDetails.setIsLastProblemSolved(1);
					doPostProcessing(chatDetails, request, queriedOn, response, null,
							chatDetails.getChatHistory().get(0).getIntentName(),
							chatDetails.getCurrentProblem().getEntities(), true);
				}
				bestIntent = chatDetails.getCurrentProblem().getIntent();
				// Proceed normally now.
			} else {
				Map<String, String> newEntities = new HashMap<>();
				luisResponse.getEntities().forEach(entity -> {
					newEntities.put(entity.getType(), entity.getEntity());
				});

				bestIntent = getIntentforBuySell(bestIntent, luisResponse.getEntities());
				if (chatDetails != null && chatDetails.getCurrentProblem() != null
						&& bestIntent.equalsIgnoreCase(chatDetails.getCurrentProblem().getIntent())) {
					// Intent matches in the existing problem, then collect
					// existing entities and new entities
					chatDetails.getCurrentProblem().getEntities().putAll(newEntities);
				}

				// To be executed if intent of new query sent by user does not
				// match with older intent in process.
				else if (chatDetails != null
						&& !bestIntent.equalsIgnoreCase(chatDetails.getCurrentProblem().getIntent())) {
					// Overwrite the current problem part of ChatDetails.
					chatDetails.getCurrentProblem().setIntent(bestIntent);
					chatDetails.getCurrentProblem().setEntities(newEntities);
					chatDetails.getCurrentProblem().setQuery(request);
				}

				// Create new object of ChatDetails if it does not exist at all.
				else if (chatDetails == null) {
					// Create new chat and insert into Mongo.
					chatDetails = new ChatDetails();
					chatDetails.setCustomerId(customerId);
					chatDetails.setChatId(customerId + "_" + 1);
					chatDetails.setStatus(1);
					chatDetails.setIsLastProblemSolved(0);
					chatDetails.setCurrentProblem(new CurrentProblem());
					chatDetails.getCurrentProblem().setIntent(bestIntent);
					chatDetails.getCurrentProblem().setEntities(newEntities);
					chatDetails.getCurrentProblem().setQuery(request);
				}

				// Indicates that last query from user has been resolved earlier
				// and new CurrentProblem needs to be initialized now.
				else {
					chatDetails.setCurrentProblem(new CurrentProblem());
					chatDetails.getCurrentProblem().setIntent(bestIntent);
					chatDetails.getCurrentProblem().setEntities(newEntities);
					chatDetails.getCurrentProblem().setQuery(request);
				}
			}

			// Get list of entities required to perform operation bound with an
			// intent.
			List<String> entityNames = getRequiredEntities(bestIntent);
			System.out.println("Intent being processed : " + bestIntent);
			List<String> missingEntities = getMissingEntities(chatDetails.getCurrentProblem().getEntities(),
					entityNames);
			Map<String, String> suggestions = new HashMap<>();
			if (missingEntities.size() > 0) {
				Map<String, String> mappedEntities = mapMissingEntities(chatDetails, missingEntities);
				if (missingEntities.size() == mappedEntities.size()) {
					response += formatMissingStatement(mappedEntities);
					suggestions.put("Yes", "yes");
					suggestions.put("No", "no");
				} else {
					response += formatReturnStatement(missingEntities);
					String suggestionIntent = luisResponse.getBestIntent().getIntent();
					if(luisResponse.getBestIntent().getIntent().equalsIgnoreCase("negative"))
						suggestionIntent = chatDetails.getChatHistory().get(0).getIntentName();
					suggestions = getSuggestions(customerId, suggestionIntent, missingEntities);
				}
				doPostProcessing(chatDetails, request, queriedOn, response, chatDetails.getCurrentProblem(),
						chatDetails.getCurrentProblem().getIntent(), chatDetails.getCurrentProblem().getEntities(),
						false);
				return getMessage(false, BotResponse.RESPONSE_TYPE_TEXT, customerId, response, null, suggestions);
			}
			System.out.println("About to perform action");
			// Process the request
			response += performAction(chatDetails);
			String intentName = chatDetails.getCurrentProblem().getIntent();
			Map<String, String> entities = chatDetails.getCurrentProblem().getEntities();
			chatDetails.setCurrentProblem(null);
			chatDetails.setIsLastProblemSolved(1);
			boolean isFailed = intentName.equalsIgnoreCase("none") ? true : false;
			doPostProcessing(chatDetails, request, queriedOn, response, null, intentName, entities, isFailed);
			return response;
		} catch (Exception e) {
			e.printStackTrace();
			return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, 0, getErrorMessage(), null, null);
		}
	}

	private String getIntentforBuySell(String intent, List<Entity> entities) {
		int counter = 0;
		for (Entity entity : entities) {
			if (entity.getType().equalsIgnoreCase("currency") || entity.getType().equalsIgnoreCase("amount"))
				counter++;
		}
		if (counter > 0) {
			if (intent.equalsIgnoreCase("buy share"))
				return "buyCurrency";
			else if (intent.equalsIgnoreCase("sell share"))
				return "sellCurrency";
		}
		return intent;
	}

	private Map<String, String> mapMissingEntities(ChatDetails chatDetails, List<String> missingEntities) {
		Map<String, String> matchingEntities = new HashMap<>();
		if (chatDetails != null && chatDetails.getChatHistory() != null && chatDetails.getChatHistory().size() > 0) {
			Collections.sort(chatDetails.getChatHistory());
			ChatHistory lastChat = chatDetails.getChatHistory().get(0);
			if (lastChat.getEntities() != null) {
				lastChat.getEntities().forEach((entityName, entityValue) -> {
					missingEntities.forEach(missingEntity -> {
						if (entityName.equalsIgnoreCase(missingEntity)) {
							matchingEntities.put(entityName, entityValue);
						}
					});
				});
			}
			lastChat.setTempEntities(matchingEntities);
		}
		return matchingEntities;
	}

	private Map<String, String> getSuggestions(int customerId, String intent, List<String> missingEntities)
			throws Exception {

		if (missingEntities.contains("company")) {
			Map<String, String> suggestions = new LinkedHashMap<>();
			tradeOperations.getTopTradedCompanies(customerId).forEach(company -> {
				suggestions.put(company.toUpperCase(), intent + " of " + company);
			});
			return suggestions;
		}
		return null;
	}

	// It involves cleanup process and updating databases once all the
	// operations are performed on a query.
	private void doPostProcessing(ChatDetails chatDetails, String request, Date queriedOn, String response,
			CurrentProblem currentProblem, String intentName, Map<String, String> entities, boolean isFailedChat) {
		Map<String, String> tempEntities = null;
		if (chatDetails != null && chatDetails.getChatHistory() != null && chatDetails.getChatHistory().size() > 0
				&& chatDetails.getChatHistory().get(0).getTempEntities() != null)
			tempEntities = chatDetails.getChatHistory().get(0).getTempEntities();
		ChatHistory chatHistory = createChatHistory(intentName, entities, tempEntities, queriedOn, request, response);
		if (chatDetails.getChatHistory() == null) {
			List<ChatHistory> hitory = new ArrayList<>();
			chatDetails.setChatHistory(hitory);
		}
		chatDetails.getChatHistory().add(chatHistory);
		if (chatDetails.get_id() == null) {
			insertChatDetails(chatDetails);
		} else {
			updateChatDetails(chatDetails, currentProblem);
		}
		if (isFailedChat) {
			// Insert the chat to failed_chats collection.
			mongoDao.save(chatHistory.getDocument(), CommonConstants.FAILED_CHATS_COLLECTION);
		}
	}

	private ChatHistory createChatHistory(String intentName, Map<String, String> entities,
			Map<String, String> tempEntities, Date queriedOn, String request, String response) {
		ChatHistory chatHistory = new ChatHistory();
		chatHistory.setIntentName(intentName);
		chatHistory.setEntities(entities);
		if (tempEntities != null)
			chatHistory.setTempEntities(tempEntities);
		chatHistory.setQueriedOn(queriedOn);
		chatHistory.setRespondedOn(new Date());
		chatHistory.setQuery(request);
		chatHistory.setResponse(response);
		return chatHistory;
	}

	// Get previous chat details of a customer.
	@SuppressWarnings("unchecked")
	private ChatDetails getChatByCustomer(int customerId) {
		Document filter = new Document();
		filter.append("customerId", customerId);
		filter.append("status", 1);
		ChatDetails chatDetails = null;

		try {
			MongoCursor<Document> cursor = mongoDao.findWithFilter(CommonConstants.CHAT_DETAILS_COLLECTION, filter)
					.iterator();

			if (cursor.hasNext()) {
				chatDetails = new ChatDetails();
				Document document = cursor.next();
				chatDetails.set_id(document.get("_id").toString());
				chatDetails.setChatId(document.get("chatId").toString());
				chatDetails.setChatHistory(
						new ChatHistory().getChatHistoryForDocument((List<Document>) document.get("chatHistory")));
				chatDetails.setCustomerId(customerId);
				chatDetails.setStatus(1);
				chatDetails.setIsLastProblemSolved(Integer.parseInt(document.get("isLastProblemSolved").toString()));
				chatDetails.setCurrentProblem(
						new CurrentProblem().getCurrentProblemFromDocument((Document) document.get("currentProblem")));
			}
			return chatDetails;
		} catch (NullPointerException e) {
			System.out.println("Chat details null");
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	private List<String> getRequiredEntities(String intentName) {
		Document filter = new Document();
		filter.append("intent", intentName);
		MongoCursor<Document> cursor = mongoDao.findWithFilter(CommonConstants.TRADE_FLOWS_COLLECTION, filter)
				.iterator();
		List<String> entityNames = null;
		if (cursor.hasNext()) {
			Document document = cursor.next();
			entityNames = (List<String>) document.get("entities");
		}
		return entityNames;
	}

	// Method to get list of entities which are required to perform an action
	// mapped with a certain intent but are missing in current statement
	// provided by user.
	private List<String> getMissingEntities(Map<String, String> entities, List<String> entityNames) {
		List<String> missingEntities = new ArrayList<String>();
		if (entityNames != null)
			entityNames.forEach(entity -> {
				if (!entities.containsKey(entity))
					missingEntities.add(entity);
			});
		return missingEntities;
	}

	private String formatReturnStatement(List<String> missingEntities) {
		String statement = "Please provide ";
		for (int i = 0; i < missingEntities.size() - 1; i++) {
			statement += missingEntities.get(i) + ",";
			if (missingEntities.get(i).equalsIgnoreCase(CommonConstants.ENTITY_NAME_COMPANY)) {
				// tradeOperations.getTopTradedCompanies();
			}
		}
		statement = statement.substring(0, statement.length() - 1);
		if (missingEntities.size() > 1)
			statement += " and ";
		statement += " " + missingEntities.get(missingEntities.size() - 1);
		return statement;
	}

	private String formatMissingStatement(Map<String, String> mappedEntities) {
		String returnStatement = "Do you want to proceed for ";
		for (String value : mappedEntities.values()) {
			returnStatement += value + ",";
		}
		return returnStatement.substring(0, returnStatement.length() - 1);
	}

	// Method to take appropriate action on the info provided by user.
	// This method will be called only when all the required information for a
	// specific operation is already collected.
	private String performAction(ChatDetails chatDetails) throws TradeException {
		String originalCompany = "";
		String existingCateg = "";
		if (chatDetails.getCurrentProblem().getEntities().get("company") != null) {
			originalCompany = chatDetails.getCurrentProblem().getEntities().get("company");
			existingCateg = setCompany(chatDetails);
		}

		switch (chatDetails.getCurrentProblem().getIntent()) {
		case "buy share":
			try {
				String category = CommonConstants.STOCK_CATEGORY_EQUITY;
				if (existingCateg!="")
					category = existingCateg;
				String responseMessage = tradeOperations.buy(chatDetails.getCustomerId(),
						chatDetails.getCurrentProblem().getEntities().get("company"),
						Integer.parseInt(chatDetails.getCurrentProblem().getEntities().get("quantity")), null,
						category);
				if (existingCateg!="")
					responseMessage = responseMessage
							.replaceAll(chatDetails.getCurrentProblem().getEntities().get("company"), originalCompany);
				return getMessage(false, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), responseMessage,
						null, null);
			} catch (TradeException e) {
				e.printStackTrace();
				return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), e.getMessage(),
						null, null);
			} catch (IOException | RuntimeException e) {
				e.printStackTrace();
				return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), getErrorMessage(),
						null, null);
			}

		case "buy_limit":
			try {
				String category = CommonConstants.STOCK_CATEGORY_EQUITY;
				if (existingCateg!="")
					category = existingCateg;
				String responseMessage = tradeOperations.buy(chatDetails.getCustomerId(),
						chatDetails.getCurrentProblem().getEntities().get("company"),
						Integer.parseInt(chatDetails.getCurrentProblem().getEntities().get("quantity")),
						new BigDecimal(chatDetails.getCurrentProblem().getEntities().get("amount")), category);
				if (existingCateg!="")
					responseMessage = responseMessage
							.replaceAll(chatDetails.getCurrentProblem().getEntities().get("company"), originalCompany);
				return getMessage(false, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), responseMessage,
						null, null);
			} catch (TradeException e) {
				e.printStackTrace();
				return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), e.getMessage(),
						null, null);
			} catch (Exception e) {
				e.printStackTrace();
				return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), getErrorMessage(),
						null, null);
			}

		case "sell share":
			try {
				String category = CommonConstants.STOCK_CATEGORY_EQUITY;
				if (existingCateg!="")
					category = existingCateg;
				String responseMessage = tradeOperations.sell(chatDetails.getCustomerId(),
						chatDetails.getCurrentProblem().getEntities().get("company"),
						Integer.parseInt(chatDetails.getCurrentProblem().getEntities().get("quantity")), null,
						category);
				if (existingCateg!="")
					responseMessage = responseMessage
							.replaceAll(chatDetails.getCurrentProblem().getEntities().get("company"), originalCompany);
				return getMessage(false, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), responseMessage,
						null, null);
			} catch (TradeException e) {
				e.printStackTrace();
				return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), e.getMessage(),
						null, null);
			} catch (RuntimeException | IOException e) {
				e.printStackTrace();
				return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), getErrorMessage(),
						null, null);
			}

		case "sell_limit":
			try {
				String responseMessage;
				String category = CommonConstants.STOCK_CATEGORY_EQUITY;
				if (existingCateg!="")
					category = existingCateg;

				responseMessage = tradeOperations.sell(chatDetails.getCustomerId(),
						chatDetails.getCurrentProblem().getEntities().get("company"),
						Integer.parseInt(chatDetails.getCurrentProblem().getEntities().get("quantity")),
						new BigDecimal(chatDetails.getCurrentProblem().getEntities().get("amount")), category);

				if (existingCateg!="")
					responseMessage = responseMessage
							.replaceAll(chatDetails.getCurrentProblem().getEntities().get("company"), originalCompany);

				return getMessage(false, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), responseMessage,
						null, null);
			} catch (TradeException e) {
				e.printStackTrace();
				return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), e.getMessage(),
						null, null);
			} catch (RuntimeException | IOException e) {
				e.printStackTrace();
				return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), getErrorMessage(),
						null, null);
			}

		case "getPortfolio":
			return getPortfolio(chatDetails);
		case "getWatchList":
			try {
				Map<String, Stock> watchListStocks = tradeOperations.getWatchlist(chatDetails.getCustomerId());
				List<VisibleWatchList> watchList = new ArrayList<>();
				for (Entry<String, Stock> share : watchListStocks.entrySet()) {
					VisibleWatchList element = new VisibleWatchList();
					element.setCurrentPrice(share.getValue().getQuote().getPrice());
					element.setStockId(share.getKey().toUpperCase());
					element.setStockName(share.getValue().getName());
					element.setTodaysGain(share.getValue().getQuote().getChange());
					element.setTodaysGainPercentage(share.getValue().getQuote().getChangeInPercent());
					element.setTodaysHigh(share.getValue().getQuote().getDayHigh());
					element.setTodaysLow(share.getValue().getQuote().getDayLow());
					watchList.add(element);
				}

				JSONArray jsonArry = new JSONArray(watchList);
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("watctList", jsonArry);
				String responseType = BotResponse.RESPONSE_TYPE_TABLE;
				String message = "Here you go : ";
				if (watchList.size() <= 0) {
					responseType = BotResponse.RESPONSE_TYPE_TEXT;
					message = "You haven't added any stock in your watch list yet.";
				}
				return getMessage(false, responseType, chatDetails.getCustomerId(), message, jsonObject.toString(),
						null);
			} catch (TradeException e) {
				e.printStackTrace();
				return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), e.getMessage(),
						null, null);
			} catch (IOException | RuntimeException e) {
				e.printStackTrace();
				return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), getErrorMessage(),
						null, null);
			}
		case "getStock":
			return getStock(chatDetails, existingCateg, originalCompany);

		case "getCurrency":
			return getCurrency(chatDetails);

		case "buyCurrency":
			return buyCurrency(chatDetails);

		case "sellCurrency":
			return sellCurrency(chatDetails);

		case "addToWatchList":
			try {
				String category = CommonConstants.STOCK_CATEGORY_EQUITY;
				if (existingCateg!="")
					category = existingCateg;
				String responseMessage = tradeOperations.addToWatchList(chatDetails.getCustomerId(),
						chatDetails.getCurrentProblem().getEntities().get("company"), category);
				if (existingCateg!="")
					responseMessage = responseMessage
							.replaceAll(chatDetails.getCurrentProblem().getEntities().get("company"), originalCompany);
				return getMessage(false, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), responseMessage,
						null, null);
			} catch (TradeException e) {
				e.printStackTrace();
				return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), e.getMessage(),
						null, null);
			} catch (IOException | RuntimeException e) {
				e.printStackTrace();
				return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), getErrorMessage(),
						null, null);
			}

		case "getBalance":
			try {
				String responseMessage = "Your current balance is $"
						+ tradeOperations.getBalance(chatDetails.getCustomerId()) + "";
				return getMessage(false, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), responseMessage,
						null, null);
			} catch (TradeException e) {
				e.printStackTrace();
				return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), e.getMessage(),
						null, null);
			} catch (Exception e) {
				e.printStackTrace();
				return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), getErrorMessage(),
						null, null);
			}

		case "addFund":
			try {
				String responseMessage = tradeOperations.addFund(chatDetails.getCustomerId(),
						Double.parseDouble(chatDetails.getCurrentProblem().getEntities().get("amount")));
				return getMessage(false, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), responseMessage,
						null, null);
			} catch (TradeException e) {
				e.printStackTrace();
				return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), e.getMessage(),
						null, null);
			} catch (Exception e) {
				e.printStackTrace();
				return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), getErrorMessage(),
						null, null);
			}

		case "greeting":
			try {
				String prefix = "Hi";

				if (Pattern.compile(Pattern.quote("good morning"), Pattern.CASE_INSENSITIVE)
						.matcher(chatDetails.getCurrentProblem().getQuery()).find()) {
					prefix = "Good Morning";
				}
				if (Pattern.compile(Pattern.quote("good afternoon"), Pattern.CASE_INSENSITIVE)
						.matcher(chatDetails.getCurrentProblem().getQuery()).find()) {
					prefix = "Good Afternoon";
				}
				if (Pattern.compile(Pattern.quote("good evening"), Pattern.CASE_INSENSITIVE)
						.matcher(chatDetails.getCurrentProblem().getQuery()).find()) {
					prefix = "Good Evening";
				}
				if (Pattern.compile(Pattern.quote("how are you"), Pattern.CASE_INSENSITIVE)
						.matcher(chatDetails.getCurrentProblem().getQuery()).find()) {
					prefix = "I am good";
				}
				String responseMessage = prefix
						+ ", How may I assist you? I can help you with trading, add funds, create watch list, show portfolio etc.";
				return getMessage(false, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), responseMessage,
						null, null);
			} catch (Exception e) {
				e.printStackTrace();
				return getMessage(true, BotResponse.RESPONSE_TYPE_IMAGE, chatDetails.getCustomerId(), getErrorMessage(),
						null, null);
			}

		case "removeFromWatchList":
			try {
				String responseMessage = tradeOperations.removeFromWatchList(chatDetails.getCustomerId(),
						chatDetails.getCurrentProblem().getEntities().get("company"));
				if (existingCateg!="")
					responseMessage = responseMessage
							.replaceAll(chatDetails.getCurrentProblem().getEntities().get("company"), originalCompany);
				return getMessage(false, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), responseMessage,
						null, null);
			} catch (TradeException e) {
				e.printStackTrace();
				return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), e.getMessage(),
						null, null);
			} catch (Exception e) {
				e.printStackTrace();
				return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), getErrorMessage(),
						null, null);
			}

			// TODO To be integrated with robo adviser
		case "getRecommendation":
			try {
				String responseMessage = tradeOperations.getRecommendations(chatDetails.getCustomerId());
				return getMessage(false, BotResponse.RESPONSE_TYPE_IMAGE, chatDetails.getCustomerId(), responseMessage,
						null, null);
			} catch (Exception e) {
				e.printStackTrace();
				return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), getErrorMessage(),
						null, null);
			}

			// TODO To be integrated with robo adviser
		case "getForecast":
			try {
				String responseMessage = tradeOperations.getForcast(chatDetails.getCustomerId());
				return getMessage(false, BotResponse.RESPONSE_TYPE_IMAGE, chatDetails.getCustomerId(), responseMessage,
						null, null);
			} catch (Exception e) {
				e.printStackTrace();
				return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), getErrorMessage(),
						null, null);
			}

		default:
			return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(),
					"Sorry, I could not understand that! I can help you with trading, add funds, create watch list, show portfolio etc.",
					null, null);
		}
	}

	// Sets the company name in current chat. Currently used for commodities
	// only for which a customer may not be able to remember exact
	private String setCompany(ChatDetails chatDetails) {
		String existingCateg = "";
		String companyName = (String) commodityProperties.get(chatDetails.getCurrentProblem().getEntities().get("company").toLowerCase());
		if (companyName != null && !companyName.equalsIgnoreCase("")) {
			existingCateg = CommonConstants.STOCK_CATEGORY_COMMODITY;
			chatDetails.getCurrentProblem().getEntities().put("company", companyName);
		}
		
		companyName = (String) companyProperties.get(chatDetails.getCurrentProblem().getEntities().get("company").toLowerCase());
		if (companyName != null && !companyName.equalsIgnoreCase("")) {
			existingCateg = CommonConstants.STOCK_CATEGORY_EQUITY;
			chatDetails.getCurrentProblem().getEntities().put("company", companyName);
		}
		return existingCateg;
	}

	private String getErrorMessage() {
		return "Sorry, I could not understand that. Please come again!";
	}

	private String getPortfolio(ChatDetails chatDetails) {

		// Get old details from portfolio
		// details and fetch all collected symbols from Yahoo.
		String report = "";
		try {
			Portfolio portfolio = tradeOperations.getPortfolio(chatDetails.getCustomerId());
			// 1. Collect list of symbols.
			VisiblePortfolio visiblePortfolio = new VisiblePortfolio();
			visiblePortfolio.setTotalCurrentValue(new BigDecimal(0));
			visiblePortfolio.setTotalInvestedValue(portfolio.getNetWorth());
			visiblePortfolio.setPortfolioDetails(new ArrayList<VisiblePortfolioDetails>());
			List<String> stockSymbols = new ArrayList<>();
			for (PortfolioDetails portfolioDetails : portfolio.getPortfolioDetails()) {
				try {
					VisiblePortfolioDetails visibleDetails = new VisiblePortfolioDetails();
					visibleDetails.setHoldPrice(portfolioDetails.getHoldValue()
							.divide(new BigDecimal(portfolioDetails.getNumOfStocks()), 2, RoundingMode.HALF_UP));
					visibleDetails.setQuantity(portfolioDetails.getNumOfStocks());
					visibleDetails.setStockId(portfolioDetails.getStock().getSymbol().toUpperCase());
					visibleDetails.setStockname(portfolioDetails.getStock().getStockName());
					stockSymbols.add(visibleDetails.getStockId());
					visiblePortfolio.getPortfolioDetails().add(visibleDetails);
				} catch (Exception e) {
					e.printStackTrace();
					continue;
				}
			}

			// Preparing object to return.
			Map<String, Stock> stockDetails = tradeOperations.getStockDetails(stockSymbols);
			for (VisiblePortfolioDetails visibleDetails : visiblePortfolio.getPortfolioDetails()) {
				try {
					visibleDetails.setCurrentPrice(stockDetails.get(visibleDetails.getStockId()).getQuote().getPrice());
					visibleDetails.setTodaysGain(stockDetails.get(visibleDetails.getStockId()).getQuote().getChange());
					visibleDetails.setTodaysGainPercentage(
							stockDetails.get(visibleDetails.getStockId()).getQuote().getChangeInPercent());
					visibleDetails
							.setOverallGain(visibleDetails.getCurrentPrice().subtract(visibleDetails.getHoldPrice()));
					visibleDetails.setOverallGainPercentage(visibleDetails.getOverallGain()
							.divide(visibleDetails.getHoldPrice(), 2, RoundingMode.HALF_UP));
					visiblePortfolio.setTotalCurrentValue(visiblePortfolio.getTotalCurrentValue().add(
							visibleDetails.getCurrentPrice().multiply(new BigDecimal(visibleDetails.getQuantity()))));
					visiblePortfolio.setTotalChange(
							visiblePortfolio.getTotalCurrentValue().subtract(visiblePortfolio.getTotalInvestedValue()));

				} catch (Exception e) {
					e.printStackTrace();
					continue;
				}
			}

			String responseType = BotResponse.RESPONSE_TYPE_TABLE;
			String message = "Here you go : ";
			if (visiblePortfolio.getPortfolioDetails().size() <= 0) {
				responseType = BotResponse.RESPONSE_TYPE_TEXT;
				message = "You haven't done any trading yet.";
			}

			report = new Gson().toJson(visiblePortfolio);

			return getMessage(false, responseType, chatDetails.getCustomerId(), message, report, null);
		} catch (TradeException e) {
			e.printStackTrace();
			return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), e.getMessage(), null,
					null);
		} catch (RuntimeException | IOException e) {
			e.printStackTrace();
			return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), getErrorMessage(),
					null, null);
		}
	}

	private String getStock(ChatDetails chatDetails, String existingCateg, String originalCompany) {
		try {
			String responseMessage = "Sorry,I could not understand that symbol!";
			String company = chatDetails.getCurrentProblem().getEntities().get("company");
			Stock stock = tradeOperations.getStock(company);
			responseMessage = "Currently " + company + " is trading at $" + stock.getQuote().getPrice()
					+ " and changed by $" + stock.getQuote().getChange() + ".";

			if (stock.getQuote().getOpen() != null) {
				responseMessage += "Today it opened at $" + stock.getQuote().getOpen();
			}
			if (stock.getQuote().getDayHigh() != null) {
				responseMessage += ", highest so far recorded at $" + stock.getQuote().getDayHigh();
			}
			if (stock.getQuote().getDayLow() != null) {
				responseMessage += " and lowest at $" + stock.getQuote().getDayLow();
			}

			if (existingCateg!="")
				responseMessage = responseMessage
						.replaceAll(chatDetails.getCurrentProblem().getEntities().get("company"), originalCompany);

			return getMessage(false, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), responseMessage, null,
					null);
		} catch (TradeException e) {
			e.printStackTrace();
			return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), e.getMessage(), null,
					null);
		} catch (IOException | RuntimeException e) {
			e.printStackTrace();
			return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), getErrorMessage(),
					null, null);
		}
	}

	private String getCurrency(ChatDetails chatDetails) {
		String responseMessage = "I could not find any matching currency. Please correct the currencies and try again.";
		FxQuote quote;
		try {
			String fromCurrency = chatDetails.getCurrentProblem().getEntities().get("currency::from");
			String toCurrency = chatDetails.getCurrentProblem().getEntities().get("currency::to");
			quote = tradeOperations.getForexQuote(fromCurrency, toCurrency);
			if (quote != null) {
				responseMessage = "Current exchange rate for " + fromCurrency + " to " + toCurrency + " is "
						+ quote.getPrice();
			}
			return getMessage(false, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), responseMessage, null,
					null);
		} catch (TradeException e) {
			e.printStackTrace();
			return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), e.getMessage(), null,
					null);
		} catch (IOException | RuntimeException e) {
			e.printStackTrace();
			return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), getErrorMessage(),
					null, null);
		}
	}

	private String buyCurrency(ChatDetails chatDetails) {
		try {
			String responseMessage = tradeOperations.buy(chatDetails.getCustomerId(),
					chatDetails.getCurrentProblem().getEntities().get("currency"), 0,
					new BigDecimal(chatDetails.getCurrentProblem().getEntities().get("amount")),
					CommonConstants.STOCK_CATEGORY_CURRENCY);
			return getMessage(false, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), responseMessage, null,
					null);
		} catch (TradeException e) {
			e.printStackTrace();
			return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), e.getMessage(), null,
					null);
		} catch (IOException | RuntimeException e) {
			e.printStackTrace();
			return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), getErrorMessage(),
					null, null);
		}
	}

	private String sellCurrency(ChatDetails chatDetails) {
		try {
			String responseMessage = tradeOperations.sell(chatDetails.getCustomerId(),
					chatDetails.getCurrentProblem().getEntities().get("currency"), 0,
					new BigDecimal(chatDetails.getCurrentProblem().getEntities().get("amount")),
					CommonConstants.STOCK_CATEGORY_CURRENCY);
			return getMessage(false, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), responseMessage, null,
					null);
		} catch (TradeException e) {
			e.printStackTrace();
			return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), e.getMessage(), null,
					null);
		} catch (RuntimeException | IOException e) {
			e.printStackTrace();
			return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, chatDetails.getCustomerId(), getErrorMessage(),
					null, null);
		}
	}

	private void updateChatDetails(ChatDetails chatDetails, CurrentProblem currentProblem) {
		chatDetails.setIsLastProblemSolved((currentProblem == null) ? 1 : 0);
		chatDetails.setCurrentProblem(currentProblem);
		Document document = chatDetails.getDocument();
		mongoDao.update(CommonConstants.CHAT_DETAILS_COLLECTION, eq("chatId", chatDetails.getChatId()),
				new Document("$set", document));
	}

	private void insertChatDetails(ChatDetails chatDetails) {
		mongoDao.save(chatDetails.getDocument(), CommonConstants.CHAT_DETAILS_COLLECTION);
	}

	@Override
	public String clearCurrentSession(int customerId) {
		try {
			ChatDetails chatDetails = getChatByCustomer(customerId);
			if (chatDetails != null) {
				chatDetails.setStatus(0);
				updateChatDetails(chatDetails, chatDetails.getCurrentProblem());
				int chatDetailsId = Integer.parseInt(chatDetails.getChatId().split("_")[1]);
				chatDetails = new ChatDetails();
				chatDetails.setCustomerId(customerId);
				chatDetails.setChatId(customerId + "_" + (++chatDetailsId));
				chatDetails.setStatus(1);
				/*List<ChatHistory> history = new ArrayList<>();
				history.add(new ChatHistory());
				chatDetails.setChatHistory(history);*/
				chatDetails.setIsLastProblemSolved(1);
				chatDetails.setCurrentProblem(null);
				insertChatDetails(chatDetails);
			}
			String reply = "You have logged-in from another device. This session is being disabled.";
			return getMessage(false, BotResponse.RESPONSE_TYPE_TEXT, customerId, reply, null, null);
		} catch (Exception e) {
			e.printStackTrace();
			return getMessage(true, BotResponse.RESPONSE_TYPE_TEXT, customerId, e.getMessage(), null, null);
		}
	}

	private String getMessage(boolean isFailure, String responseType, int customerId, String message, String data,
			Map<String, String> suggestions) {
		BotResponse botResponse = new BotResponse();
		if (isFailure) {
			botResponse.setCode(BotResponse.FAILURE_CODE);
			botResponse.setStatus(BotResponse.FAILURE_STATUS);
		} else {
			botResponse.setCode(BotResponse.SUCCESS_CODE);
			botResponse.setStatus(BotResponse.SUCCESS_STATUS);
		}
		botResponse.setResponseType(responseType);
		botResponse.setCustomerId(customerId);
		botResponse.setMessage(message);
		botResponse.setData(data);
		if (suggestions != null) {
			botResponse.setSuggestions(suggestions);
		}

		JSONObject botReply = new JSONObject(botResponse);

		if (data != null) {
			JSONObject dataObject = new JSONObject(data);
			botReply.put("data", dataObject);
		}

		return botReply.toString();
		// return new Gson().toJson(botResponse);
	}

	@Override
	@Transactional
	public String isCustomerPresent(int customerId) {
		String successMsg = "Customer found with customerId " + customerId;
		String failureMsg = "No customer found with customerId " + customerId;
		boolean customerExists = (tradeOperations.getCustomer(customerId) == null) ? false : true;
		return getMessage(!customerExists, BotResponse.RESPONSE_TYPE_TEXT, customerId,
				customerExists ? successMsg : failureMsg, null, null);
	}
	
	@Override
	@Transactional
	public String isCustomerPresent(String username, String password) {
		String successMsg = "Customer found with username " + username;
		String failureMsg = "No customer found with username " + username;
		LoginCredentials credentials = tradeOperations.getCustomerByUsernameAndPassword(username, password);
		boolean customerExists = (credentials == null) ? false : true;
		String customerProfile = null;
		if(customerExists){
			Document filter = new Document();
			filter.put("customerId", credentials.getCustomer().getCustomerId());
			filter.put("status", CommonConstants.STATUS_ACTIVE);
			MongoCursor<Document> cursor = mongoDao.findWithFilter(CommonConstants.SIGNUP_DETAILS_COLLECTION, filter).iterator();
			if(cursor.hasNext()){
				Document document = cursor.next();
				customerProfile = document.toJson();
			}
		}
		return getMessage(!customerExists, BotResponse.RESPONSE_TYPE_TEXT,
				credentials == null ? -1 : credentials.getCustomer().getCustomerId(),
				customerExists ? successMsg : failureMsg, customerProfile, null);
	}

	@Override
	@Transactional
	public String signUp(String userName, String password) {
		Integer customerId = createAccount(userName, password);
		return getMessage(customerId==null, BotResponse.RESPONSE_TYPE_TEXT, customerId==null?-1:customerId,
			customerId!=null ? "Successfully signed up" : "Username already exists, please choose other username.", null, null);
	}

	private Integer createAccount(String username, String password) {

		List<Customer> presentCustomers = customerDao.findByColumn(Customer.class, "username", username);
		if (presentCustomers != null && presentCustomers.size() > 0)
			return null;

		Customer customer = new Customer();
		customer.setDateOfBirth(new Date());
		customer.setCreatedOn(new Date());
		customer.setUpdatedOn(new Date());
		customer.setCreatedBy(null);
		customer.setUpdatedBy(null);
		customer.setStatus(1);
		customer.setUsername(username);
		customerDao.insert(customer);

		BankAccount bankAccount = new BankAccount();
		bankAccount.setCustomer(customer);
		bankAccount.setBalance(0);
		bankAccount.setStatus(CommonConstants.STATUS_ACTIVE);
		bankAccount.setAccountNumber(new Integer(customer.getCustomerId()).toString());
		bankAccount.setCreatedBy(new Integer(customer.getCustomerId()).toString());
		bankAccount.setUpdatedBy(new Integer(customer.getCustomerId()).toString());
		bankAccount.setCreatedOn(new Date());
		bankAccount.setUpdatedOn(new Date());
		bankAccountDao.insert(bankAccount);

		LoginCredentials creds = new LoginCredentials();
		creds.setCreatedBy(new Integer(customer.getCustomerId()).toString());
		creds.setUpdatedBy(new Integer(customer.getCustomerId()).toString());
		creds.setCreatedOn(new Date());
		creds.setUpdatedOn(new Date());
		creds.setCustomer(customer);
		creds.setUserName(username);
		creds.setPassword(password);
		loginCredentialsDao.insert(creds);
		return customer.getCustomerId();
	}

	
	@Override
	public String saveSignUpData(int customerId, String profileData) {

		String status = "failed";
		
		Document document = new Document();
		document.append("customerId", customerId);

		JSONObject json = new JSONObject(profileData);

		for (Iterator<String> key = json.keys(); key.hasNext();) {
			String elem = key.next();
			document.append(elem, json.get(elem));
		}
		Document filter = new Document();
		filter.put("customerId", customerId);
		MongoCursor<Document> cursor = mongoDao.findWithFilter(CommonConstants.SIGNUP_DETAILS_COLLECTION, filter)
				.iterator();
		if (cursor.hasNext())
			mongoDao.findOneAndReplace(CommonConstants.SIGNUP_DETAILS_COLLECTION, filter, document);
		else
			mongoDao.save(document, CommonConstants.SIGNUP_DETAILS_COLLECTION);
		status = "success";
		return status;
	}

	public static void main(String[] args) {
		String name = "saumitra";
		boolean m = Pattern.compile(Pattern.quote("umi"), Pattern.CASE_INSENSITIVE).matcher(name).find();
		System.out.println(m);
	}
}
