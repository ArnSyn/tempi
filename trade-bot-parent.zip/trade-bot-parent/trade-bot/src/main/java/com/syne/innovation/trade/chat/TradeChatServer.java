/* *
 * Trade bot chat server to handle multiple client
 * */
package com.syne.innovation.trade.chat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import org.json.JSONObject;

@ServerEndpoint("/chat/{customerId}")
public class TradeChatServer {

	// Maintain unique set of client sessions
	private static Set<Session> clients = Collections
			.synchronizedSet(new HashSet<Session>());
	//private static final String tradeurl = "http://35.160.185.197:8080/trade-bot";
	private static final String tradeurl = "http://52.213.122.61:8080/trade-bot";

	@OnOpen
	public void onOpen(Session session) {
		String currentClientId =session.getPathParameters().get("customerId");
		for (Session client : clients) {
			String oldClientId =client.getPathParameters().get("customerId");
			if (oldClientId.equals(currentClientId)) {
				// Call restful service to send appropriate response to user
				//String replyMessage = callService(session.getPathParameters().get("customerId"), "Kill Old Sessions", "clearsession");
				
				JSONObject reply = new JSONObject();
				reply.put("code", 000);
				reply.put("status", "Success");
				reply.put("message", "You have logged-in from another device. Your current session is being disabled");
				reply.put("customerId",oldClientId);
				reply.put("responseType", "text");
				try {
					client.getBasicRemote().sendText(reply.toString());
				} catch (IOException e) {
					e.printStackTrace();
				}
				onClose(client);
			}
		}
		clients.add(session);
		try {
			session.getBasicRemote().sendText("Welcome to Fin360 Bot!!");
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Client Connected !! " + session);
	}

	@OnClose
	public void onClose(Session session) {
		clients.remove(session);
		System.out.println("Client Closed !!");
	}

	@OnMessage
	public void onMessage(String request, Session session) throws IOException {
		JSONObject jsonRequest = new JSONObject(request);
//		String custId = jsonRequest.getString("customerId");
		String messageType = jsonRequest.getString("messageType");
		String message = jsonRequest.getString("message");
		String customerId =session.getPathParameters().get("customerId");
		synchronized (clients) {
			// Iterate over the connected sessions and send reply	
			for (Session client : clients) {
				if (client.equals(session)) {
					// Call restful service to send appropriate response to user
					String replyMessage = callService(customerId, message, messageType);
					client.getBasicRemote().sendText(replyMessage);
				}
			}
		}
	}

	// Restful service call to trade bot back end to answer user query
	public String callService(String custId, String query, String queryType) {
		String output = "";
		try {
			URL url = null;
			if (queryType.equals("query")) {
				url = new URL(tradeurl + "/trade?customerId=" + custId + "&q="	+ URLEncoder.encode(query, "UTF-8"));
				System.out.println("URL" + url);
			} else if (queryType.equals("clearsession")) {
				url = new URL(tradeurl + "/clear?customerId=" + custId);
			}
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "text/plain");

			if (conn.getResponseCode() != 200) {
				System.out.println("Failed : HTTP error code : "
						+ conn.getResponseCode());
			} else {
				System.out.println(conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream())));

			System.out.println("Output from Server .... \n");
			while ((output = br.readLine()) != null) {
				System.out.println(output);
				return output;
			}
			conn.disconnect();
			System.out.println("Disconnect");
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return output;
	}
}
