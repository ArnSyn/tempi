package com.syne.innovation.trade.controller;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.syne.innovation.trade.service.TradeFlow;
import com.syne.innovation.trade.speech.SpeechToTextConverter;

@Controller
public class TradeController {

	
	@Autowired
	private TradeFlow tradeFlow;
	
	@Autowired
	private SpeechToTextConverter converter;
	
	@RequestMapping("/trade")
	@ResponseBody
	public String trade(@RequestParam(value="q", required=true) String q, @RequestParam(value="customerId", required=true) int customerId){
		return tradeFlow.processChat(q, customerId);
	}
	
	@RequestMapping("/clear")
	@ResponseBody
	public String clearSession(@RequestParam(value="customerId", required=true) int customerId){
		return tradeFlow.clearCurrentSession(customerId);
	}
	
	@RequestMapping("/login")
	@ResponseBody
	public String login(@RequestParam(value="customerId", required=true) int customerId){
		return tradeFlow.isCustomerPresent(customerId);
	}
	
	@RequestMapping("/signin")
	@ResponseBody
	public String login(@RequestParam(value = "username", required = true) String username,
			@RequestParam(value = "password", required = true) String password) {
		return tradeFlow.isCustomerPresent(username, password);
	}
	
	@RequestMapping(value="/signup", method=RequestMethod.POST)
	@ResponseBody
	public String signup(@RequestParam(value="username", required=true) String username, @RequestParam(value="password", required=true) String password){
		return tradeFlow.signUp(username, password);
	}
	
	@RequestMapping(value="/saveprofile", method=RequestMethod.POST)
	@ResponseBody
	public String saveProfile(@RequestParam(value="customerId", required=true) int customerId, @RequestBody String profileData){
		return tradeFlow.saveSignUpData(customerId, profileData);
	}
	
	@RequestMapping("/vocaltrade")
	@ResponseBody
	// TODO make sure :
	// 1. File path is provided from front end.
	// 2. Can be done even without file type being provided explicitly. Pass file type from front end as well if not possible.
	public String vocalTrade(@RequestParam(value="customerId", required=true) int customerId, @RequestParam(value="fileType", required=true) String fileType,
			@RequestParam(value="filePath", required=true) String filePath){
		String chat = converter.convert(new File(filePath));
		return tradeFlow.processChat(chat, customerId);
	}
}
