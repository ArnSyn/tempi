package com.syne.innovation.trade.nlp;

import com.syne.innovation.trade.vo.LuisResponse;
/*
 * Contains methods to perform NLP on the input provided.
 */
public interface NlpService {
	
	// Parses a sentence and provides the intent and entities found in the input.
	public LuisResponse parseSentence(String url);
	
}
