package com.syne.innovation.trade.nlp;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.syne.innovation.trade.vo.LuisResponse;
/*
 * Contains methods to perform NLP on the input provided.
 */
@Component
public class NlpServiceImpl implements NlpService{

	/*@Value("${app_id}")
	private String appId;
	
	@Value("${subscription_id}")
	private String subscriptionId;*/
	
	@Value("${api_url}")
	private String apiUrl;
	
	// Parses a sentence and provides the intent and entities found in the input.
	@Override
	public LuisResponse parseSentence(String url) {
		try {
			url=prepareUrl(url);
			JsonNode node = Unirest.get(url).asJson().getBody();
			Gson gson = new Gson();
			LuisResponse response = gson.fromJson(node.toString(), LuisResponse.class);
			return response;
		} catch (UnirestException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	private String prepareUrl(String query) {
		try {
			//return String.format(apiUrl, appId, subscriptionId, URLEncoder.encode(query, "UTF-8"));
			return String.format(apiUrl, URLEncoder.encode(query, "UTF-8"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return null;
	}
}
