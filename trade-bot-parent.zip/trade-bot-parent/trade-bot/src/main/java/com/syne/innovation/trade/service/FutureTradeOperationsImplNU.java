package com.syne.innovation.trade.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.PostConstruct;
import javax.jms.JMSException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.syne.innovation.trade.constants.CommonConstants;
import com.syne.innovation.trade.queue.Consumer;
import com.syne.innovation.trade.queue.LimitStock;
import com.syne.innovation.trade.queue.Producer;

import yahoofinance.Stock;

@Component
public class FutureTradeOperationsImplNU extends Thread implements FutureTradeOpeartionsNU {

	Map<String, List<LimitStock>> buyStocks = new HashMap<>();
	Map<String, List<LimitStock>> sellStocks = new HashMap<>();

	@Autowired
	private ApplicationContext context;
	
	@Autowired
	private Consumer consumer;

	@Autowired
	private Producer producer;

	@Autowired
	private TradeOperations tradeOperations;

	private boolean isThreadStarted = false;

	@Override
	public String doTransaction(boolean isBuy, String symbol, int quantity, BigDecimal price, int customerId)
			throws JMSException {
		consumer = new Consumer();
		producer = new Producer();
		LimitStock limitStock = new LimitStock();
		limitStock.setCustomerId(customerId);
		limitStock.setLimitPrice(price);
		limitStock.setNumberOfStocks(quantity);
		limitStock.setSymbol(symbol);
		producer.produce(CommonConstants.BUY_QUEUE_NAME, limitStock);
//		startThread();
		isThreadStarted = true;
		return "Stock added successfully";
	}

	//@PostConstruct
	public void startThread() {
		
		if (!isThreadStarted) {
			FutureTradeOperationsImplNU operations = context.getBean(FutureTradeOperationsImplNU.class);
			// Thread brokerThread = new Thread(new FutureTradeOperationsImpl());
			operations.start();
		}
	}

	private void getBuyQueue() {
		try {
			consumer = new Consumer();
			LimitStock limitStock = consumer.consume(CommonConstants.BUY_QUEUE_NAME);
			while (limitStock != null) {
				if (buyStocks.get(limitStock.getSymbol()) == null)
					buyStocks.put(limitStock.getSymbol(), new ArrayList<LimitStock>());
				buyStocks.get(limitStock.getSymbol()).add(limitStock);
				limitStock = consumer.consume(CommonConstants.BUY_QUEUE_NAME);
			}
		} catch (JMSException e) {
			e.printStackTrace();
			return;
		}
	}

	private void getSellQueue() {
		try {
			LimitStock limitStock = consumer.consume(CommonConstants.SELL_QUEUE_NAME);
			while (limitStock != null) {
				if (buyStocks.get(limitStock.getSymbol()) == null)
					buyStocks.put(limitStock.getSymbol(), new ArrayList<LimitStock>());
				buyStocks.get(limitStock.getSymbol()).add(limitStock);
				limitStock = consumer.consume(CommonConstants.SELL_QUEUE_NAME);
			}
		} catch (JMSException e) {
			e.printStackTrace();
			return;
		}
	}

	@Override
	public void run() {
		while (true) {
			try {
				getBuyQueue();
				getSellQueue();
				Map<String, Stock> stocks = tradeOperations.getStockDetails(new ArrayList<>(buyStocks.keySet()));
				stocks.putAll(tradeOperations.getStockDetails(new ArrayList<>(sellStocks.keySet())));
				for (Entry<String, Stock> entry : stocks.entrySet()) {
					Iterator<LimitStock> iterator = buyStocks.get(entry.getKey()).iterator();
					while(iterator.hasNext())
					{	
						LimitStock limitStock = iterator.next();
						if (entry.getValue().getQuote().getPrice().compareTo(limitStock.getLimitPrice()) == 0) {
							tradeOperations.buy(limitStock.getCustomerId(), limitStock.getSymbol(),
									limitStock.getNumberOfStocks(), limitStock.getLimitPrice(), CommonConstants.STOCK_CATEGORY_EQUITY);
							iterator.remove();
						}
					}
					iterator = buyStocks.get(entry.getKey()).iterator();
					while(iterator.hasNext()){
						LimitStock limitStock = iterator.next();
						if (entry.getValue().getQuote().getPrice().compareTo(limitStock.getLimitPrice()) == 0) {
							tradeOperations.sell(limitStock.getCustomerId(), limitStock.getSymbol(),
									limitStock.getNumberOfStocks(), limitStock.getLimitPrice(), CommonConstants.STOCK_CATEGORY_EQUITY);
							iterator.remove();
						}
					}
				}
			} catch (Exception e) {
				//e.printStackTrace();
				continue;
			}
		}
	}
}