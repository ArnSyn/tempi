package com.syne.innovation.trade.persistence.entity;

import java.math.BigDecimal;

public class PortfolioDetailResponse {

	private Stock stock;
	
	private BigDecimal tradeAmount;

	public Stock getStock() {
		return stock;
	}

	public void setStock(Stock stock) {
		this.stock = stock;
	}

	public BigDecimal getTradeAmount() {
		return tradeAmount;
	}

	public void setTradeAmount(BigDecimal tradeAmount) {
		this.tradeAmount = tradeAmount;
	}
	
}
