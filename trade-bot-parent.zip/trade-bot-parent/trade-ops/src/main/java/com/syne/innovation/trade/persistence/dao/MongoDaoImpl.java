package com.syne.innovation.trade.persistence.dao;

import org.bson.Document;
import org.bson.conversions.Bson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoDatabase;

/*
 * Contains all the MongoDB related operations.
 */
@Component
public class MongoDaoImpl implements MongoDao {

	@Autowired
	private MongoConnector mongoConnector;

	// Inserts a new document into specified collection.
	@Override
	public void save(Document document, String collection) {
		MongoDatabase db = mongoConnector.getConnection();
		db.getCollection(collection).insertOne(document);
	}

	// Updates an existing document based upon the criteria provided in filter
	// document.
	@Override
	public void update(String collection, Bson filter, Document update) {
		MongoDatabase db = mongoConnector.getConnection();
		db.getCollection(collection).updateOne(filter, update);
	}
	
	// Updates an existing document based upon the criteria provided in filter
	// document.
	@Override
	public void findOneAndReplace(String collection, Bson filter, Document update) {
		MongoDatabase db = mongoConnector.getConnection();
		db.getCollection(collection).findOneAndReplace(filter, update);
	}

	// Returns an iterator on all the matching documents of the filter document
	// for the specified collection.
	@Override
	public FindIterable<Document> findWithFilter(String collection, Document filter) {
		MongoDatabase db = mongoConnector.getConnection();
		return db.getCollection(collection).find(filter);
	}
}