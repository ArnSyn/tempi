package com.syne.innovation.trade.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.syne.innovation.trade.constants.CommonConstants;
import com.syne.innovation.trade.exception.TradeException;
import com.syne.innovation.trade.persistence.dao.GenericDao;
import com.syne.innovation.trade.persistence.entity.BankAccount;
import com.syne.innovation.trade.persistence.entity.Customer;
import com.syne.innovation.trade.persistence.entity.LoginCredentials;
import com.syne.innovation.trade.persistence.entity.Portfolio;
import com.syne.innovation.trade.persistence.entity.PortfolioDetailResponse;
import com.syne.innovation.trade.persistence.entity.PortfolioDetails;
import com.syne.innovation.trade.persistence.entity.StockTransaction;
import com.syne.innovation.trade.persistence.entity.WatchList;
import com.syne.innovation.trade.persistence.entity.WatchListDetails;

import yahoofinance.Stock;
import yahoofinance.YahooFinance;
import yahoofinance.quotes.fx.FxQuote;

/**
 * Contains all the core operations that a user may want to perform on a trading
 * tool. Gets data from NMS.
 *
 */
@Service
public class TradeOperationsImpl implements TradeOperations {

	@Autowired
	private GenericDao<PortfolioDetails, Integer> portfolioDetailsDao;

	@Autowired
	private GenericDao<Customer, Integer> customerDao;

	@Autowired
	private GenericDao<Portfolio, Integer> portfolioDao;

	@Autowired
	private GenericDao<WatchList, Integer> watchListDao;

	@Autowired
	private GenericDao<com.syne.innovation.trade.persistence.entity.Stock, Integer> stockDao;

	@Autowired
	private GenericDao<BankAccount, Integer> bankAccountDao;

	@Autowired
	private GenericDao<StockTransaction, Integer> stockTransactionDao;

	@Autowired
	private GenericDao<WatchListDetails, Integer> watchListDetailsDao;

	@Autowired
	private GenericDao<LoginCredentials, Integer> loginCredentialsDao;

	// Returns current price of provided symbol.
	@Override
	public BigDecimal getCurrentPrice(String symbol) throws IOException {
		Stock stock = YahooFinance.get(symbol);
		return stock.getQuote().getPrice();
	}

	// Returns details of stocks.
	@Override
	public Map<String, Stock> getStockDetails(List<String> symbols) throws IOException {
		if (symbols == null || symbols.size() < 1) {
			return new HashMap<String, Stock>();
		}
		return YahooFinance.get(symbols.toArray((new String[0])));
	}

	// Returns day's change in percentage for the provided symbol.
	@Override
	public Stock getStock(String symbol) throws IOException {
		Stock stock = YahooFinance.get(symbol);
		return stock;
	}

	// Returns day's change in amount for the provided symbol.
	@Override
	public BigDecimal getChange(String symbol) throws IOException {

		Stock stock = YahooFinance.get(symbol);
		return stock.getQuote().getChange();
	}

	// Performs buy operation and add an entry to User's portfolio.
	// Also updates Transaction table.
	@Transactional
	@Override
	public String buy(int customerId, String symbol, int numberOfStocks, BigDecimal price, String category)
			throws IOException {
		System.out.println("Going to purchase " + numberOfStocks + " shares of " + symbol);
		try {
			Stock stock;
			FxQuote fxQuote;
			String stockName;
			String originalSymbol = symbol;
			boolean isStock = category.equalsIgnoreCase(CommonConstants.STOCK_CATEGORY_EQUITY)
					|| category.equalsIgnoreCase(CommonConstants.STOCK_CATEGORY_COMMODITY);
			BigDecimal amount = price;
			try {
				if (category.equalsIgnoreCase(CommonConstants.STOCK_CATEGORY_EQUITY)
						|| category.equalsIgnoreCase(CommonConstants.STOCK_CATEGORY_COMMODITY)) {
					stock = YahooFinance.get(symbol);
					if (stock == null || stock.getQuote()==null || stock.getQuote().getPrice()==null)
						throw new TradeException("Invalid symbol received. Please verify and send another request.");
					if (price != null && price.compareTo(new BigDecimal(0)) > 0)
						stock.getQuote().setPrice(price);
					price = stock.getQuote().getPrice();
					symbol = stock.getSymbol();
					stockName = stock.getName();
				} else {
					symbol = symbol.toUpperCase() + "USD" + "=X";
					fxQuote = YahooFinance.getFx(symbol);
					if (fxQuote == null)
						throw new TradeException("Invalid currency received. Please verify and send another request.");
					stockName = fxQuote.getSymbol();
					numberOfStocks = amount.multiply(fxQuote.getPrice()).intValue();
					price = fxQuote.getPrice().setScale(2, BigDecimal.ROUND_HALF_UP);
				}
			} catch (Exception e) {
				e.printStackTrace();
				throw new TradeException("Invalid stock symbol received. Please verify and send another request.");
			}
			Customer customer = getCustomer(customerId);
			if (customer == null)
				throw new TradeException(
						"No customer found with customer Id " + customerId + ". Please provide a valid customer Id.");
			if (!hasEnoughFund(customer, numberOfStocks, isStock, price))
				return "Sorry! You dont have enough funds to buy " + numberOfStocks + " stocks of " + symbol + ".";
			com.syne.innovation.trade.persistence.entity.Stock myStock = new com.syne.innovation.trade.persistence.entity.Stock();
			Portfolio portfolio = getPortfolio(customer);
			PortfolioDetailResponse response = updatePortfolioDetails(portfolio, numberOfStocks, symbol, stockName,
					price, true, myStock, category);
			updatePortfolio(portfolio, response.getTradeAmount());
			myStock = response.getStock();
			createTransaction(myStock, customer, "buy", new Double(response.getTradeAmount().toString()));
			if (category.equalsIgnoreCase(CommonConstants.STOCK_CATEGORY_EQUITY)
					|| category.equalsIgnoreCase(CommonConstants.STOCK_CATEGORY_COMMODITY)) {
				return "Congratulations! You have successfully purchased " + numberOfStocks + " stocks of " + symbol
						+ ".";
			}
			if (category.equalsIgnoreCase(CommonConstants.STOCK_CATEGORY_COMMODITY)) {
				return "Congratulations! You have successfully purchased " + numberOfStocks + " lots of " + symbol
						+ ".";
			}
			return "Congratulations! You have successfully purchased " + originalSymbol + " worth $" + amount;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Transactional
	private boolean hasEnoughFund(Customer customer, int numOfStocks, boolean isStock, BigDecimal price) {
		BankAccount bankAccount = getBankAccount(customer);
		if (bankAccount == null) {
			throw new TradeException("No bank account configured customer Id " + customer.getCustomerId()
					+ ". Please contact customer support to open a new bank account.");
		}
		if (isStock && bankAccount.getBalance() >= new Double(price.toString()) * numOfStocks)
			return true;
		else if (!isStock && bankAccount.getBalance() > new Double(price.toString()))
			return true;
		return false;
	}

	private BankAccount getBankAccount(Customer customer) {
		Map<String, Object> filters = new HashMap<>();
		filters.put("customer", customer);
		filters.put("status", CommonConstants.STATUS_ACTIVE);
		List<BankAccount> bankAccounts = bankAccountDao.findByKeyValue(BankAccount.class, filters);
		if (bankAccounts != null && bankAccounts.size() > 0) {
			return bankAccounts.get(0);
		}
		return null;
	}

	// Returns the list of stocks with details already purchased by user.
	@Transactional
	@Override
	public Portfolio getPortfolio(int customerId) {
		Customer customer = getCustomer(customerId);
		if (customer == null) {
			throw new TradeException(
					"No customer found with customer Id " + customerId + ". Please provide a valid customer Id.");
		}
		return getPortfolio(customer);
	}

	// Fetches Portfolio for a customer, creates a new portfolio if none exists.
	private Portfolio getPortfolio(Customer customer) {
		Map<String, Object> filters = new HashMap<>();
		filters.put("customer", customer);
		filters.put("status", CommonConstants.STATUS_ACTIVE);
		List<Portfolio> portfolios = portfolioDao.findByKeyValue(Portfolio.class, filters);
		Portfolio portfolio;
		if (portfolios == null || portfolios.size() == 0) {
			// Create a new portfolio.
			portfolio = new Portfolio();
			portfolio.setStatus(CommonConstants.STATUS_ACTIVE);
			portfolio.setCustomer(customer);
			portfolio.setCreatedOn(new Date());
			portfolio.setCreatedBy("System");
			portfolioDao.persist(portfolio);
		} else {
			// Assuming there will be only 1 active portfolio at a time.
			portfolio = portfolios.get(0);
			portfolio.getPortfolioDetails();
		}
		return portfolio;
	}

	private PortfolioDetailResponse updatePortfolioDetails(Portfolio portfolio, int numberOfStocks, String symbol,
			String stockName, BigDecimal stockPrice, boolean isBuy,
			com.syne.innovation.trade.persistence.entity.Stock stock, String category) {
		// Get stock from db. Create a new entry if it does not exist.
		List<com.syne.innovation.trade.persistence.entity.Stock> stocks = stockDao
				.findByColumn(com.syne.innovation.trade.persistence.entity.Stock.class, "symbol", symbol);

		PortfolioDetails portfolioDetails;

		if (stocks != null && stocks.size() > 0) {
			stock = stocks.get(0);
			portfolioDetails = updateExistingPortfolio(portfolio, stockPrice, stock, numberOfStocks, isBuy);
		} else {
			// Create a new stock and insert into the db.
			// If a stock does not exist, porttfolio_details will also not be
			// available. Create new PortfolioDetails.
			createNewStock(symbol, stockName, stockPrice, stock, category);
			portfolioDetails = createPortfolioDetails(portfolio, numberOfStocks, stockPrice, isBuy);
		}

		portfolioDetails.setStock(stock);
		portfolioDetails.setUpdatedBy("System");
		portfolioDetails.setUpdatedOn(new Date());
		portfolioDetailsDao.persist(portfolioDetails);
		PortfolioDetailResponse response = new PortfolioDetailResponse();
		response.setStock(stock);
		response.setTradeAmount(stockPrice.multiply(new BigDecimal(numberOfStocks)));
		if (!isBuy) {
			response.setTradeAmount(response.getTradeAmount().multiply(new BigDecimal(-1)));
		}
		if (portfolioDetails.getHoldValue() == null)
			portfolioDetails.setHoldValue(response.getTradeAmount());
		else
			portfolioDetails.setHoldValue(portfolioDetails.getHoldValue().add(response.getTradeAmount()));
		return response;
	}

	// Creates new Portfolio Details if none existing for the stock, updates
	// otherwise.
	private PortfolioDetails updateExistingPortfolio(Portfolio portfolio, BigDecimal stockPrice,
			com.syne.innovation.trade.persistence.entity.Stock stock, int numberOfStocks, boolean isBuy) {
		PortfolioDetails portfolioDetails;
		// Average out the price if a stock already exists in user's portfolio.
		Map<String, Object> filters = new HashMap<>();
		filters.put("portfolio", portfolio);
		filters.put("status", CommonConstants.STATUS_ACTIVE);
		filters.put("stock", stock);
		List<PortfolioDetails> details = portfolioDetailsDao.findByKeyValue(PortfolioDetails.class, filters);
		if (details != null && details.size() > 0) {
			portfolioDetails = details.get(0);
			if (isBuy) {
				portfolioDetails.setNumOfStocks(portfolioDetails.getNumOfStocks() + numberOfStocks);
				portfolioDetails.setAveragePrice(
						(portfolioDetails.getAveragePrice().multiply(new BigDecimal(portfolioDetails.getNumOfStocks())))
								.add(stockPrice.multiply(new BigDecimal(numberOfStocks))).divide(
										new BigDecimal(portfolioDetails.getNumOfStocks() + numberOfStocks), 2,
										RoundingMode.HALF_UP));
			} else {
				portfolioDetails.setNumOfStocks(portfolioDetails.getNumOfStocks() - numberOfStocks);
			}
		} else {
			portfolioDetails = createPortfolioDetails(portfolio, numberOfStocks, stockPrice, isBuy);
		}
		return portfolioDetails;
	}

	private PortfolioDetails createPortfolioDetails(Portfolio portfolio, int numberOfStocks, BigDecimal stockPrice,
			boolean isBuy) {
		// New PortfolioDetails.
		PortfolioDetails portfolioDetails = new PortfolioDetails();
		portfolioDetails.setLastTransactionDate(new Date());
		portfolioDetails.setPortfolio(portfolio);
		portfolioDetails.setStatus(CommonConstants.STATUS_ACTIVE);

		if (isBuy) {
			portfolioDetails.setNumOfStocks(numberOfStocks);
			portfolioDetails.setAveragePrice(stockPrice);
		} else {
			portfolioDetails.setNumOfStocks(numberOfStocks * -1);
			portfolioDetails.setAveragePrice(stockPrice.multiply(new BigDecimal(-1)));
		}

		return portfolioDetails;
	}

	private void createNewStock(String symbol, String stockName, BigDecimal stockPrice,
			com.syne.innovation.trade.persistence.entity.Stock stock, String category) {
		stock.setStockName(stockName);
		stock.setSymbol(symbol);
		stock.setLastPrice(stockPrice);
		stock.setStatus(CommonConstants.STATUS_ACTIVE);
		stock.setLastUpdatedOn(new Date());
		stock.setCreatedBy("System");
		stock.setCreatedOn(new Date());
		stock.setUpdatedBy("System");
		stock.setUpdatedOn(new Date());
		stock.setCategory(category);
		stockDao.persist(stock);
	}

	private void updatePortfolio(Portfolio portfolio, BigDecimal amount) {
		if (portfolio.getNetWorth() == null)
			portfolio.setNetWorth(amount);
		else
			portfolio.setNetWorth(portfolio.getNetWorth().add(amount));

		portfolio.setUpdatedOn(new Date());
		portfolio.setUpdatedBy("System");
		portfolioDao.persist(portfolio);
	}

	private void createTransaction(com.syne.innovation.trade.persistence.entity.Stock stock, Customer customer,
			String transactionType, Double transactionAmount) {
		StockTransaction transaction = new StockTransaction();
		transaction.setCustomer(customer);
		transaction.setStock(stock);
		transaction.setTransactionAmount(transactionAmount);
		transaction.setTransactionDate(new Date());
		transaction.setTransactionType(transactionType);
		transaction.setStatus(CommonConstants.STATUS_ACTIVE);
		transaction.setUpdatedOn(new Date());
		transaction.setUpdatedBy("System");
		transaction.setCreatedOn(new Date());
		transaction.setCreatedBy("System");
		stockTransactionDao.persist(transaction);

		// Update balance in bank account.
		BankAccount bankAccount = getBankAccount(customer);
		if (bankAccount != null) {
			bankAccount.setBalance(bankAccount.getBalance() - transactionAmount);
			bankAccount.setUpdatedBy("System");
			bankAccount.setUpdatedOn(new Date());
			bankAccountDao.persist(bankAccount);
		}
	}

	// TODO Performs buy operation and add an entry to User's portfolio whenever
	// the said amount is reached.
	// Also updates Transaction table.
	@Transactional
	@Override
	public boolean buyWithLimit(String symbol, BigDecimal limitAmount) throws IOException {
		/*
		 * Stock stock = YahooFinance.get(symbol); BigDecimal price =
		 * stock.getQuote().getPrice();
		 */
		return false;
	}

	// Performs sell operation and removes an entry from User's portfolio.
	// Also updates Transaction table.
	@Transactional
	@Override
	public String sell(int customerId, String symbol, int numberOfStocks, BigDecimal price, String category)
			throws IOException {
		try {
			Stock stock;
			FxQuote fxQuote;
			String stockName;
			String originalSymbol = symbol;
			boolean isStock = category.equalsIgnoreCase(CommonConstants.STOCK_CATEGORY_EQUITY)
					|| category.equalsIgnoreCase(CommonConstants.STOCK_CATEGORY_COMMODITY);
			try {
				if (isStock) {
					stock = YahooFinance.get(symbol);
					if (stock == null)
						throw new TradeException("Invalid symbol received. Please verify and send another request.");
					if (price != null && price.compareTo(new BigDecimal(0)) > 0)
						stock.getQuote().setPrice(price);
					price = stock.getQuote().getPrice();
					symbol = stock.getSymbol();
					stockName = stock.getName();
				} else {
					symbol = symbol.toUpperCase() + "USD" + "=X";
					fxQuote = YahooFinance.getFx(symbol);
					if (fxQuote == null)
						throw new TradeException("Invalid currency received. Please verify and send another request.");
					stockName = fxQuote.getSymbol();
					numberOfStocks = price.divide(fxQuote.getPrice(), 2, RoundingMode.HALF_UP).intValue();
					price = fxQuote.getPrice().setScale(2, BigDecimal.ROUND_HALF_UP);
				}
			} catch (Exception e) {
				e.printStackTrace();
				throw new TradeException("Invalid symbol/currency received. Please verify and send another request.");
			}
			com.syne.innovation.trade.persistence.entity.Stock myStock = new com.syne.innovation.trade.persistence.entity.Stock();
			Customer customer = getCustomer(customerId);
			if (customer == null)
				throw new TradeException(
						"No customer found with customer Id " + customerId + ". Please provide a valid customer Id.");
			if (getBankAccount(customer) == null) {
				throw new TradeException("No bank account configured for customer Id " + customerId
						+ ". Please contact customer support to open a new bank account.");
			}
			Portfolio portfolio = getPortfolio(customer);
			PortfolioDetailResponse response = updatePortfolioDetails(portfolio, numberOfStocks, symbol, stockName,
					price, false, myStock, category);
			updatePortfolio(portfolio, response.getTradeAmount());
			myStock = response.getStock();
			createTransaction(myStock, customer, "sell", new Double(response.getTradeAmount().toString()));
			if (category.equalsIgnoreCase(CommonConstants.STOCK_CATEGORY_EQUITY))
				return "Successfully sold " + numberOfStocks + " stocks of " + symbol;
			else if (category.equalsIgnoreCase(CommonConstants.STOCK_CATEGORY_COMMODITY))
				return "Successfully sold " + numberOfStocks + " lots of " + symbol;
			return "Successfully sold " + originalSymbol + " worth $" + price;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	// TODO Performs sell operation and removes an entry from User's portfolio
	// whenever the said amount is reached..
	// Also updates Transaction table.
	@Transactional
	@Override
	public boolean sellWithLimit(String symbol, BigDecimal limitAmount) throws IOException {
		// Stock stock = YahooFinance.get(symbol);
		return false;
	}

	// Returns details of all the stock that a user has in Watchlist.
	@Transactional
	@Override
	public Map<String, Stock> getWatchlist(int customerId) throws IOException {
		Map<String, Stock> items = new HashMap<>();
		Customer customer = getCustomer(customerId);
		if (customer == null)
			throw new TradeException(
					"No customer found with customer Id " + customerId + ". Please provide a valid customer Id.");
		Map<String, Object> filters = new HashMap<>();
		filters.put("customer", customer);
		filters.put("status", CommonConstants.STATUS_ACTIVE);
		List<WatchList> watchLists = watchListDao.findByKeyValue(WatchList.class, filters);
		if (watchLists == null || watchLists.size() == 0)
			return items;
		WatchList watchList = watchLists.get(0);
		if (watchList.getWatchListDetails() != null) {
			for (WatchListDetails detail : watchList.getWatchListDetails()) {
				if (detail.getStatus() == CommonConstants.STATUS_ACTIVE)
					items.put(detail.getStock().getSymbol(), YahooFinance.get(detail.getStock().getSymbol()));
			}
		}
		return items;
	}

	/*
	 * Add a new stock to the watchlist of provided customer.
	 */
	@Transactional
	@Override
	public String addToWatchList(int customerId, String symbol, String category) throws IOException {
		Customer customer = getCustomer(customerId);
		if (customer == null)
			throw new TradeException(
					"No customer found with customer Id " + customerId + ". Please provide a valid customer Id.");
		if (YahooFinance.get(symbol).getName() == null)
			throw new TradeException(symbol + " is not a valid symbol for any stock!");
		Map<String, Object> filters = new HashMap<>();
		filters.put("customer", customer);
		filters.put("status", CommonConstants.STATUS_ACTIVE);
		List<WatchList> watchLists = watchListDao.findByKeyValue(WatchList.class, filters);
		WatchList watchList;
		com.syne.innovation.trade.persistence.entity.Stock stock = new com.syne.innovation.trade.persistence.entity.Stock();
		if (watchLists != null && watchLists.size() > 0) {
			watchList = watchLists.get(0);
		} else {
			// Create watchlist
			watchList = new WatchList();
			watchList.setCustomer(customer);
			watchList.setStatus(CommonConstants.STATUS_ACTIVE);
			watchList.setCreatedBy("System");
			watchList.setCreatedOn(new Date());
			watchList.setUpdatedBy("System");
			watchList.setUpdatedOn(new Date());
			watchListDao.persist(watchList);

		}

		List<com.syne.innovation.trade.persistence.entity.Stock> stocks = stockDao
				.findByColumn(com.syne.innovation.trade.persistence.entity.Stock.class, "symbol", symbol);

		if (stock == null || stocks.size() == 0) {
			Stock yahooStock;
			try {
				yahooStock = YahooFinance.get(symbol);
			} catch (Exception e) {
				e.printStackTrace();
				throw new TradeException("Invalid stock symbol received. Please verify and send another request.");
			}
			createNewStock(yahooStock.getSymbol(), yahooStock.getName(), yahooStock.getQuote().getPrice(), stock,
					category);
		} else {
			stock = stocks.get(0);
		}

		WatchListDetails details = new WatchListDetails();
		details.setStock(stock);
		details.setWatchList(watchList);
		details.setStatus(CommonConstants.STATUS_ACTIVE);
		details.setCreatedBy("System");
		details.setCreatedOn(new Date());
		details.setUpdatedBy("System");
		details.setUpdatedOn(new Date());
		watchListDetailsDao.persist(details);

		return "Successfully added " + symbol + " to your watchList.";
	}

	/*
	 * Remove an existing stock from the watchlist of provided customer.
	 */
	@Transactional
	@Override
	public String removeFromWatchList(int customerId, String symbol) throws IOException {
		Customer customer = getCustomer(customerId);
		if (customer == null)
			throw new TradeException(
					"No customer found with customer Id " + customerId + ". Please provide a valid customer Id.");
		Map<String, Object> filters = new HashMap<>();
		filters.put("customer", customer);
		filters.put("status", CommonConstants.STATUS_ACTIVE);
		List<WatchList> watchLists = watchListDao.findByKeyValue(WatchList.class, filters);
		WatchList watchList;
		com.syne.innovation.trade.persistence.entity.Stock stock = new com.syne.innovation.trade.persistence.entity.Stock();
		if (watchLists != null && watchLists.size() > 0) {
			watchList = watchLists.get(0);
		} else {
			throw new TradeException("No watchlist found for customer id : " + customerId);
		}

		List<com.syne.innovation.trade.persistence.entity.Stock> stocks = stockDao
				.findByColumn(com.syne.innovation.trade.persistence.entity.Stock.class, "symbol", symbol);

		if (stock == null || stocks.size() == 0) {
			throw new TradeException("You don't have " + symbol + " in your watchlist.");
		}

		stock = stocks.get(0);

		filters.clear();
		filters.put("watchList", watchList);
		filters.put("status", CommonConstants.STATUS_ACTIVE);
		filters.put("stock", stock);
		List<WatchListDetails> watchListDetails = watchListDetailsDao.findByKeyValue(WatchListDetails.class, filters);
		if (watchListDetails == null || watchListDetails.size() == 0) {
			throw new TradeException("You don't have " + symbol + " in your watchlist.");
		}
		WatchListDetails details = watchListDetails.get(0);
		details.setStatus(CommonConstants.STATUS_INACTIVE);
		watchListDetailsDao.persist(details);

		return "Successfully removed " + symbol + " from your watchList.";
	}

	// TODO Return top 10 losers of the day.
	public List topLosers() {
		return null;
	}

	// TODO Returns top 10 gainers of the day.
	public List topGainers() {
		return null;
	}

	// Adds fund in user's account and returns the balance available.
	@Transactional
	@Override
	public String addFund(int customerId, Double amount) {
		try {
			Customer customer = getCustomer(customerId);
			if (customer == null) {
				throw new TradeException(
						"No customer found with customer Id " + customerId + ". Please provide a valid customer Id.");
			}
			List<BankAccount> accounts = bankAccountDao.findByColumn(BankAccount.class, "customer", customer);
			if (accounts == null || accounts.size() < 1) {
				throw new TradeException("No valid bank account found for customer Id " + customerId
						+ ". Please get in touch with our customer support to open a new bank account.");
			}
			BankAccount account = accounts.get(0);
			account.setBalance(account.getBalance() + amount);
			bankAccountDao.persist(account);
			return "Successfully added $" + amount + " to your account and your updated balance is $"
					+ BigDecimal.valueOf(account.getBalance()).setScale(2, RoundingMode.HALF_UP).doubleValue();
		} catch (Exception e) {
			e.printStackTrace();
			throw new TradeException(e.getMessage());
		}
	}

	@Transactional
	@Override
	public double getBalance(int customerId) {

		Customer customer = getCustomer(customerId);
		if (customer == null) {
			throw new TradeException(
					"No customer found with customer Id " + customerId + ". Please provide a valid customer Id.");
		}

		Map<String, Object> filters = new HashMap<>();
		filters.put("customer", customer);
		filters.put("status", CommonConstants.STATUS_ACTIVE);
		List<BankAccount> accounts = bankAccountDao.findByKeyValue(BankAccount.class, filters);
		if (accounts == null || accounts.size() < 1) {
			throw new TradeException("No valid bank account found for customer Id " + customerId
					+ ". Please get in touch with our customer support to open a new bank account.");
		}
		if (accounts.size() > 0) {
			BankAccount account = accounts.get(0);
			Double balance = (account != null) ? account.getBalance() : -1;
			balance = BigDecimal.valueOf(balance).setScale(2, RoundingMode.HALF_UP).doubleValue();
			return balance;
		}
		return -1;
	}

	// Returns the symbols of companies with which the user has traded most or
	// has recently added in watchlist.
	@Override
	@Transactional
	public Set<String> getTopTradedCompanies(int customerId) throws Exception {
		try {
			Map<String, Object> filters = new HashMap<>();
			filters.put("customer", customerDao.find(Customer.class, customerId));
			filters.put("status", CommonConstants.STATUS_ACTIVE);
			List<String> orderFields = new ArrayList<>();
			Set<Integer> stockIds = new LinkedHashSet<>();

			List<Portfolio> portfolios = portfolioDao.findByKeyValue(Portfolio.class, filters);
			List<WatchList> watchlists = watchListDao.findByKeyValue(WatchList.class, filters);

			if (portfolios != null && portfolios.size() > 0) {
				Portfolio portfolio = portfolios.get(0);
				filters.clear();
				filters.put("portfolio", portfolio);
				filters.put("status", CommonConstants.STATUS_ACTIVE);
				orderFields.add("numOfStocks");
				orderFields.add("updatedOn");
				portfolioDetailsDao.getByCriteria(PortfolioDetails.class, filters, null, orderFields,
						CommonConstants.MAX_RESULTS_TOP_TRADED).forEach(portfolioDetails -> {
							stockIds.add(portfolioDetails.getStock().getStockId());
						});
			}

			if (watchlists != null && watchlists.size() > 0) {

				WatchList watchlist = watchlists.get(0);
				orderFields.clear();
				filters.clear();
				orderFields.add("updatedOn");
				filters.put("status", CommonConstants.STATUS_ACTIVE);
				filters.put("watchList", watchlist);
				Map<String, Object> notMatching = new HashMap<>();
				if (stockIds.size() > 0)
					notMatching.put("stock.stockId", stockIds);
				for (WatchListDetails watchListDetails : watchListDetailsDao.getByCriteria(WatchListDetails.class,
						filters, notMatching, orderFields, CommonConstants.MAX_RESULTS_TOP_TRADED)) {
					stockIds.add(watchListDetails.getStock().getStockId());
				}
			}
			Set<String> topTradedCompanies = new LinkedHashSet<>();
			if (stockIds != null && stockIds.size() > 0) {
				List<com.syne.innovation.trade.persistence.entity.Stock> stocks = stockDao
						.findByIds(com.syne.innovation.trade.persistence.entity.Stock.class, "stockId", stockIds);
				int counter = 0;
				for (com.syne.innovation.trade.persistence.entity.Stock stock : stocks) {
					if (stock.getCategory().equalsIgnoreCase(CommonConstants.STOCK_CATEGORY_EQUITY)) {
						topTradedCompanies.add(stock.getSymbol());
						counter++;
						if (counter == CommonConstants.MAX_RESULTS_TOP_TRADED)
							break;
					}
				}
			}
			return topTradedCompanies;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public Customer getCustomer(int customerId) {
		Map<String, Object> filters = new HashMap<>();
		filters.put("customerId", customerId);
		filters.put("status", CommonConstants.STATUS_ACTIVE);
		List<Customer> customers = customerDao.findByKeyValue(Customer.class, filters);
		if (customers != null && customers.size() > 0) {
			return customers.get(0);
		}
		return null;
	}

	@Override
	public String getRecommendations(int customerId) throws MalformedURLException, IOException {
		byte[] imageBytes = IOUtils
				.toByteArray(this.getClass().getClassLoader().getResourceAsStream("images/recommendations.png"));
		String base64 = Base64.getEncoder().encodeToString(imageBytes);
		return base64;
	}

	@Override
	public String getForcast(int customerId) throws MalformedURLException, IOException {
		byte[] imageBytes = IOUtils
				.toByteArray(this.getClass().getClassLoader().getResourceAsStream("images/projections.png"));
		String base64 = Base64.getEncoder().encodeToString(imageBytes);
		return base64;
	}

	@Override
	public FxQuote getForexQuote(String fromCurrency, String toCurrency) throws IOException {
		if (fromCurrency != null && toCurrency != null)
			return YahooFinance.getFx(fromCurrency + toCurrency + "=X");
		return null;
	}
	
	@Override
	public LoginCredentials getCustomerByUsernameAndPassword(String username, String password) {
		Map<String, Object> filter = new HashMap<>();
		filter.put("userName", username);
		filter.put("password", password);
		List<LoginCredentials> credentials = loginCredentialsDao.findByKeyValue(LoginCredentials.class, filter);
		if (credentials != null && credentials.size() > 0) {
			System.out.println(credentials.get(0).getCustomer().getCustomerId());
			return credentials.get(0);
		}
		return null;
	}

	public static void main(String[] args) throws IOException {
		Stock q = YahooFinance.get("Grtyt" + "=X");
		// Stock q = YahooFinance.get("GC=F");

		System.out.println(q);
	}
}
