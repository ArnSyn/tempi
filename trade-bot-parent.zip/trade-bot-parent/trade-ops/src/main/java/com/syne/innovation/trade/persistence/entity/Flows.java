package com.syne.innovation.trade.persistence.entity;

import java.util.List;

import com.syne.innovation.trade.vo.Entity;
import com.syne.innovation.trade.vo.Intent;

// Collection to store all the configured flows.
public class Flows {
	private int flowId;
	private Intent intent;
	private List<Entity> entities;
	public int getFlowId() {
		return flowId;
	}
	public void setFlowId(int flowId) {
		this.flowId = flowId;
	}
	public Intent getIntent() {
		return intent;
	}
	public void setIntent(Intent intent) {
		this.intent = intent;
	}
	public List<Entity> getEntities() {
		return entities;
	}
	public void setEntities(List<Entity> entities) {
		this.entities = entities;
	}
}
