package com.syne.innovation.trade.vo;

import java.util.HashMap;
import java.util.Map;

public class BotResponse {

	public static String SUCCESS_CODE = "000";
	public static String FAILURE_CODE = "101";

	public static String SUCCESS_STATUS = "success";
	public static String FAILURE_STATUS = "failed";

	public static String RESPONSE_TYPE_TEXT = "text";
	public static String RESPONSE_TYPE_IMAGE = "image";
	public static String RESPONSE_TYPE_PICHART = "pichart";
	public static String RESPONSE_TYPE_TABLE = "table";

	private String code;

	private String status;

	private int customerId;

	private String responseType;

	private String message;

	private String data;

	private Map<String, String> suggestions = new HashMap<>();

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getResponseType() {
		return responseType;
	}

	public void setResponseType(String responseType) {
		this.responseType = responseType;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public Map<String, String> getSuggestions() {
		return suggestions;
	}

	public void setSuggestions(Map<String, String> suggestions) {
		this.suggestions = suggestions;
	}
}
