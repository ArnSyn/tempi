package com.syne.innovation.trade.persistence.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="portfolio_details")
public class PortfolioDetails {

	@Id
	@Column(name="PortfolioDetailsId")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int portfolioDetailsId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "PortfolioId", nullable = false)
	private Portfolio portfolio;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "StockId", nullable = false)
	private Stock stock;
	
	private int numOfStocks;
	
	private BigDecimal averagePrice;
	
	private BigDecimal holdValue;
	
	public BigDecimal getHoldValue() {
		return holdValue;
	}

	public void setHoldValue(BigDecimal holdValue) {
		this.holdValue = holdValue;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	private Date lastTransactionDate;
	
	// Denotes the current Status of details. 0:Inactive, 1:Active 
	private int status;
	
	private String createdBy;
	
	private Date createdOn;
	
	private String updatedBy;
	
	private Date updatedOn;

	public Portfolio getPortfolio() {
		return portfolio;
	}

	public void setPortfolio(Portfolio portfolio) {
		this.portfolio = portfolio;
	}

	public Stock getStock() {
		return stock;
	}

	public void setStock(Stock stock) {
		this.stock = stock;
	}

	public int getNumOfStocks() {
		return numOfStocks;
	}

	public void setNumOfStocks(int numOfStocks) {
		this.numOfStocks = numOfStocks;
	}
	
	public BigDecimal getAveragePrice() {
		return averagePrice;
	}

	public void setAveragePrice(BigDecimal averagePrice) {
		this.averagePrice = averagePrice;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public Date getLastTransactionDate() {
		return lastTransactionDate;
	}

	public void setLastTransactionDate(Date lastTransactionDate) {
		this.lastTransactionDate = lastTransactionDate;
	}

	public int getPortfolioDetailsId() {
		return portfolioDetailsId;
	}

	public void setPortfolioDetailsId(int portfolioDetailsId) {
		this.portfolioDetailsId = portfolioDetailsId;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
	
}
