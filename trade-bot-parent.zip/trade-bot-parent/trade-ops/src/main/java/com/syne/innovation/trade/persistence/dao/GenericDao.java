package com.syne.innovation.trade.persistence.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;

/*
 * Contains methods to perform CRUD operations in MySQL.
 */
public interface GenericDao<T, ID extends Serializable> {

	// Creates a new record or updates if primary key is already present in DB
	public void persist(T entity);

	// Deletes a record from the table.
	public void delete(T entity);

	// Finds and returns a record whose primary key matches.
	public T find(Class<T> entity, ID id);

	// Returns all the records of a table.
	public List<T> findAll(Class<T> entity);

	// Returns all the matching rows from the table. Input map contains column
	// names and their values on which table needs to be queried.
	public List<T> findByKeyValue(Class<T> entity, Map<String, Object> conditions);

	// Returns all the records of a table where value matches for the provided
	// column.
	public List<T> findByColumn(Class<T> entity, String columnName, Object value);

	public List<T> getByCriteria(Class<T> entity, Map<String, Object> conditions, Map<String, Object> notMatching, List<String> sortColumns, int maxResults) throws Exception;

	public List<T> findByIds(Class<T> entity, String idColumn, Set<ID> ids);

	public void insert(T entity);
}