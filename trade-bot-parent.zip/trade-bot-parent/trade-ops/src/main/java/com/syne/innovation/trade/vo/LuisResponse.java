package com.syne.innovation.trade.vo;

import java.util.List;

public class LuisResponse {
	private List<Intent> intents;
	private List<Entity> entities;
	private String query;

	public List<Intent> getIntents() {
		return intents;
	}

	public void setIntents(List<Intent> intents) {
		this.intents = intents;
	}

	public List<Entity> getEntities() {
		return entities;
	}

	public void setEntities(List<Entity> entities) {
		this.entities = entities;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public Intent getBestIntent() {
		double maxScore = 0.0;
		Intent bestIntent = null;
		for (Intent intent : intents) {
			if (intent.getScore() > maxScore) {
				bestIntent = intent;
				maxScore = intent.getScore();
			}
		}
		return bestIntent;
	}

	public Entity getBestEntity() {
		double maxScore = 0.0;
		Entity bestEntity = null;
		for (Entity entity : entities) {
			if (entity.getScore() > maxScore) {
				bestEntity = entity;
				maxScore = entity.getScore();
			}
		}
		return bestEntity;
	}
}
