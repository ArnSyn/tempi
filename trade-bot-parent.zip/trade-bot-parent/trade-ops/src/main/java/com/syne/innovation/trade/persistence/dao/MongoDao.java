package com.syne.innovation.trade.persistence.dao;

import org.bson.Document;
import org.bson.conversions.Bson;

import com.mongodb.client.FindIterable;
/*
 * Contains all the MongoDB related operations.
 */
public interface MongoDao {

	// Inserts a new document into specified collection.
	public void save(Document document, String collection);

	//Updates an existing document based upon the criteria provided in filter document.
	public void update(String collection, Bson filter, Document update);

	// Returns an iterator on all the matching documents of the filter document for the specified collection.
	public FindIterable<Document> findWithFilter(String collection, Document filter);

	public void findOneAndReplace(String collection, Bson filter, Document update);
}
