package com.syne.innovation.trade.vo;

public class Intent {
	
	private double score;
	private String intent;
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	public String getIntent() {
		return intent;
	}
	public void setIntent(String intent) {
		this.intent = intent;
	}
}
