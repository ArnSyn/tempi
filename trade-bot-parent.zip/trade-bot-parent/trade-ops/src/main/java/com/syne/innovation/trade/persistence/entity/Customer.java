package com.syne.innovation.trade.persistence.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="customer")
public class Customer {

	@Id
	@Column(name = "CustomerId")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int customerId;
	
	private String emailId;
	
	private String username;
	
	private Date dateOfBirth;
	
	private String gender;
	
	private int status;
	
	private String createdBy;
	
	private Date createdOn;
	
	private String updatedBy;
	
	private Date updatedOn;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "customer")
	private List<LoginDetails> loginDetails = new ArrayList<LoginDetails>();
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "customer")
	private List<BankAccount> bankAccounts = new ArrayList<BankAccount>();
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "customer")
	private List<Portfolio> portfolios = new ArrayList<Portfolio>();
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "customer")
	private List<LoginCredentials> loginCredentials = new ArrayList<LoginCredentials>();
	
	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public List<LoginCredentials> getLoginCredentials() {
		return loginCredentials;
	}

	public void setLoginCredentials(List<LoginCredentials> loginCredentials) {
		this.loginCredentials = loginCredentials;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "customer")
	private List<StockTransaction> stockTransactions = new ArrayList<StockTransaction>();

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public List<LoginDetails> getLoginDetails() {
		return loginDetails;
	}

	public void setLoginDetails(List<LoginDetails> loginDetails) {
		this.loginDetails = loginDetails;
	}

	public List<BankAccount> getBankAccounts() {
		return bankAccounts;
	}

	public void setBankAccounts(List<BankAccount> bankAccounts) {
		this.bankAccounts = bankAccounts;
	}

	public List<Portfolio> getPortfolios() {
		return portfolios;
	}

	public void setPortfolios(List<Portfolio> portfolios) {
		this.portfolios = portfolios;
	}

	public List<StockTransaction> getStockTransactions() {
		return stockTransactions;
	}

	public void setStockTransactions(List<StockTransaction> stockTransactions) {
		this.stockTransactions = stockTransactions;
	}
	
}