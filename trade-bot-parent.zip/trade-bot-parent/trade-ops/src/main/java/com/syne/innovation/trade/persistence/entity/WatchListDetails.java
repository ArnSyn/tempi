package com.syne.innovation.trade.persistence.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "watchlist_Details")
public class WatchListDetails {

	@Id
	@Column(name = "WatchListDetailsId")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int watchListDetailsId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "WatchListId", nullable = false)
	private WatchList watchList;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "StockId", nullable = false)
	private Stock stock;

	private int status;

	private String createdBy;

	private Date createdOn;

	private String updatedBy;

	private Date updatedOn;

	public int getWatchListDetailsId() {
		return watchListDetailsId;
	}

	public void setWatchListDetailsId(int watchListDetailsId) {
		this.watchListDetailsId = watchListDetailsId;
	}

	public WatchList getWatchList() {
		return watchList;
	}

	public void setWatchList(WatchList watchList) {
		this.watchList = watchList;
	}

	public Stock getStock() {
		return stock;
	}

	public void setStock(Stock stock) {
		this.stock = stock;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
}
