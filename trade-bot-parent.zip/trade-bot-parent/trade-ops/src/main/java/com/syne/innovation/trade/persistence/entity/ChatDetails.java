package com.syne.innovation.trade.persistence.entity;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.bson.types.ObjectId;

public class ChatDetails {

	private String _id;

	private int customerId;

	private String chatId;

	private int status;

	private int isLastProblemSolved;

	private CurrentProblem currentProblem;

	private List<ChatHistory> chatHistory;

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getChatId() {
		return chatId;
	}

	public void setChatId(String chatId) {
		this.chatId = chatId;
	}

	public CurrentProblem getCurrentProblem() {
		return currentProblem;
	}

	public void setCurrentProblem(CurrentProblem currentProblem) {
		this.currentProblem = currentProblem;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getIsLastProblemSolved() {
		return isLastProblemSolved;
	}

	public void setIsLastProblemSolved(int isLastProblemSolved) {
		this.isLastProblemSolved = isLastProblemSolved;
	}

	public List<ChatHistory> getChatHistory() {
		return chatHistory;
	}

	public void setChatHistory(List<ChatHistory> chatHistory) {
		this.chatHistory = chatHistory;
	}

	public Document getDocument() {
		Document document = new Document();
		if (_id != null)
			document.append("_id", new ObjectId(_id));
		document.append("customerId", customerId);
		document.append("chatId", chatId);
		document.append("status", status);
		document.append("isLastProblemSolved", isLastProblemSolved);
		List<Document> historyDocuments = new ArrayList<>();
		if (chatHistory != null) {
			for (ChatHistory history : chatHistory) {
				historyDocuments.add(history.getDocument());
			}
		}
		document.append("chatHistory", historyDocuments);
		if (currentProblem != null)
			document.append("currentProblem", currentProblem.getDocument());
		else
			document.append("currentProblem", null);
		return document;
	}
}
