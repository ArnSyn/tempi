package com.syne.innovation.trade.persistence.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
/*
 * Contains methods to perform CRUD operations in MySQL.
 */
@Repository
public class GenericDaoImpl<T, ID extends Serializable> implements GenericDao<T, ID>{
 
    @Autowired
    private SessionFactory sessionFactory;
 
    // TO get the current session.
    protected Session getSession() {
        return sessionFactory.getCurrentSession();
    }
 
    // Creates a new record or updates if primary key is already present in DB
    @Override
    public void persist(T entity) {
        getSession().saveOrUpdate(entity);
    }
    
    // Creates a new record or updates if primary key is already present in DB
    @Override
    public void insert(T entity) {
        getSession().save(entity);
    }
 
    // Deletes a record from the table.
    @Override
    public void delete(T entity) {
        getSession().delete(entity);
    }

    // Finds and returns a record whose primary key matches.
    @SuppressWarnings("unchecked")
	@Override
	public T find(Class<T> entity, ID id) {
		return (T) getSession().load(entity, id);
	}
    
    // Returns all the records of a table.
    @SuppressWarnings("unchecked")
	@Override
    public List<T> findAll(Class<T> entity){
    	return (List<T>) getSession().createCriteria(entity).list();
    }
    
    // Returns all the records of a table where value matches for the provided column.
    @SuppressWarnings("unchecked")
	@Override
    public List<T> findByColumn(Class<T> entity, String columnName, Object value){
    	Criteria criteria = getSession().createCriteria(entity);
    	criteria.add(Restrictions.eqOrIsNull(columnName, value));
    	return criteria.list();
    }
    
    // Returns all the matching rows from the table. Input map contains column names and their values on which table needs to be queried.
    @SuppressWarnings("unchecked")
	@Override
    public List<T> findByKeyValue(Class<T> entity, Map<String, Object> conditions){
    	Criteria criteria = getSession().createCriteria(entity);
    	for(Entry<String, Object> e: conditions.entrySet()){
        	criteria.add(Restrictions.eqOrIsNull(e.getKey(), e.getValue()));
    	}
    	return criteria.list();
    }
    
    // Finds and returns records whose primary key matches.
    @SuppressWarnings("unchecked")
	@Override
	public List<T> findByIds(Class<T> entity, String idColumn, Set<ID> ids) {
    	Criteria criteria = getSession().createCriteria(entity);
    	criteria.add(Restrictions.in(idColumn, ids));
    	return criteria.list();
	}
    
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<T> getByCriteria(Class<T> entity, Map<String, Object> conditions, Map<String, Object> notMatching,
			List<String> sortColumns, int maxResults) throws Exception {
		Criteria criteria = getSession().createCriteria(entity);
		if (conditions != null && conditions.size()>0){
			for (Entry<String, Object> e : conditions.entrySet()) {
				criteria.add(Restrictions.eqOrIsNull(e.getKey(), e.getValue()));
			}
		}
		if (notMatching != null && notMatching.size()>0){
			for (Entry<String, Object> e : notMatching.entrySet()) {
				if (e.getValue() instanceof Set){
					List list = new ArrayList<>();
					list.addAll((Set)e.getValue());
					criteria.add(Restrictions.not(Restrictions.in(e.getKey(), list)));
				}
				else
					criteria.add(Restrictions.ne(e.getKey(), e.getValue()));
			}
		}
		if(sortColumns!=null && sortColumns.size()>0){
		for (String column : sortColumns)
			criteria.addOrder(Order.desc(column));
		}
		criteria.setMaxResults(maxResults);
		return criteria.list();
	}
}