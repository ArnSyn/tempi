package com.syne.innovation.trade.vo;

import java.math.BigDecimal;

public class VisiblePortfolioDetails {

	private String stockId;

	private String stockname;

	private int quantity;

	private BigDecimal currentPrice;

	private BigDecimal holdPrice;

	private BigDecimal overallGain;

	private BigDecimal overallGainPercentage;

	private BigDecimal todaysGain;

	private BigDecimal todaysGainPercentage;

	public String getStockId() {
		return stockId;
	}

	public void setStockId(String stockId) {
		this.stockId = stockId;
	}

	public String getStockname() {
		return stockname;
	}

	public void setStockname(String stockname) {
		this.stockname = stockname;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public BigDecimal getCurrentPrice() {
		return currentPrice;
	}

	public void setCurrentPrice(BigDecimal currentPrice) {
		this.currentPrice = currentPrice;
	}

	public BigDecimal getHoldPrice() {
		return holdPrice;
	}

	public void setHoldPrice(BigDecimal holdPrice) {
		this.holdPrice = holdPrice;
	}

	public BigDecimal getOverallGain() {
		return overallGain;
	}

	public void setOverallGain(BigDecimal overallGain) {
		this.overallGain = overallGain;
	}

	public BigDecimal getOverallGainPercentage() {
		return overallGainPercentage;
	}

	public void setOverallGainPercentage(BigDecimal overallGainPercentage) {
		this.overallGainPercentage = overallGainPercentage;
	}

	public BigDecimal getTodaysGain() {
		return todaysGain;
	}

	public void setTodaysGain(BigDecimal todaysGain) {
		this.todaysGain = todaysGain;
	}

	public BigDecimal getTodaysGainPercentage() {
		return todaysGainPercentage;
	}

	public void setTodaysGainPercentage(BigDecimal todaysGainPercentage) {
		this.todaysGainPercentage = todaysGainPercentage;
	}

	@Override
	public String toString() {
		return stockId + "\t" + stockname + "\t" + quantity + "\t" + currentPrice + "\t" + holdPrice + "\t"
				+ overallGain + "\t" + overallGainPercentage + "\t" + todaysGain + "\t" + todaysGainPercentage;
	}

}
