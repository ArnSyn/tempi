package com.syne.innovation.trade.persistence.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="watchList")
public class WatchList {
	
	@Id
	@Column(name = "WatchListId")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int watchListId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CustomerId", nullable = false)
	private Customer customer;
	
	// 0:Inactive, 1:Active
	private int status;
	
	private String createdBy;
	
	private Date createdOn;
	
	private String updatedBy;
	
	private Date updatedOn;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "watchList")
	private List<WatchListDetails> watchListDetails = new ArrayList<WatchListDetails>();

	public int getWatchListId() {
		return watchListId;
	}

	public void setWatchListId(int watchListId) {
		this.watchListId = watchListId;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public List<WatchListDetails> getWatchListDetails() {
		return watchListDetails;
	}

	public void setWatchListDetails(List<WatchListDetails> watchListDetails) {
		this.watchListDetails = watchListDetails;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
}