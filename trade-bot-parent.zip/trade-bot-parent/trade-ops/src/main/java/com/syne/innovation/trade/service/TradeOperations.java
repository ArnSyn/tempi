package com.syne.innovation.trade.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.syne.innovation.trade.persistence.entity.Customer;
import com.syne.innovation.trade.persistence.entity.LoginCredentials;
import com.syne.innovation.trade.persistence.entity.Portfolio;

import yahoofinance.Stock;
import yahoofinance.quotes.fx.FxQuote;

/**
 * Contains all the core operations that a user may want to perform on a trading
 * tool. Gets data from NMS.
 *
 */
public interface TradeOperations {

	// Returns current price of provided symbol.
	public BigDecimal getCurrentPrice(String symbol) throws IOException;

	// Returns day's change in percentage for the provided symbol.
	public Stock getStock(String symbol) throws IOException;

	// Returns day's change in amount for the provided symbol.
	public BigDecimal getChange(String symbol) throws IOException;

	// Returns the list of stocks with details already purchased by user.
	public Portfolio getPortfolio(int customerId);

	// Performs buy operation and add an entry to User's portfolio.
	// Also updates Transaction table.
	public String buy(int customerId, String symbol, int numberOfStocks, BigDecimal price, String category) throws IOException;

	// TODO Performs buy operation and add an entry to User's portfolio whenever
	// the said amount is reached.
	// Also updates Transaction table.
	public boolean buyWithLimit(String symbol, BigDecimal limitAmount) throws IOException;

	// Performs sell operation and removes an entry from User's portfolio.
	// Also updates Transaction table.
	public String sell(int customerId, String symbol, int numberOfStocks, BigDecimal price, String category) throws IOException;

	// Performs sell operation and removes an entry from User's portfolio
	// whenever the said amount is reached..
	// Also updates Transaction table.
	public boolean sellWithLimit(String symbol, BigDecimal limitAmount) throws IOException;

	// Returns details of all the stock that a user has in Watchlist.
	public Map<String, Stock> getWatchlist(int customerId) throws IOException;

	// Add a stock to user's watch list.
	public String addToWatchList(int customerId, String symbol, String category) throws IOException;
	
	// Remove a stock from user's watch list.
	public String removeFromWatchList(int customerId, String symbol) throws IOException;

	// Adds fund in user's account and returns the balance available.
	public String addFund(int customerId, Double amount);

	public Map<String, Stock> getStockDetails(List<String> symbols) throws IOException;

	public double getBalance(int customerId);

	public Set<String> getTopTradedCompanies(int customerId) throws Exception;

	public Customer getCustomer(int customerId);

	public String getRecommendations(int customerId) throws MalformedURLException, IOException;

	public String getForcast(int customerId) throws MalformedURLException, IOException;

	public FxQuote getForexQuote(String fromCurrency, String toCurrency) throws IOException;

	public LoginCredentials getCustomerByUsernameAndPassword(String username, String password);

}
