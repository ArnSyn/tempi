package com.syne.innovation.trade.vo;

import java.math.BigDecimal;

public class VisibleWatchList {
	private String stockId;

	private String stockName;

	private BigDecimal currentPrice;

	private BigDecimal todaysGain;

	private BigDecimal todaysGainPercentage;

	private BigDecimal todaysHigh;

	private BigDecimal todaysLow;

	public String getStockId() {
		return stockId;
	}

	public void setStockId(String stockId) {
		this.stockId = stockId;
	}

	public String getStockName() {
		return stockName;
	}

	public void setStockName(String stockName) {
		this.stockName = stockName;
	}

	public BigDecimal getCurrentPrice() {
		return currentPrice;
	}

	public void setCurrentPrice(BigDecimal currentPrice) {
		this.currentPrice = currentPrice;
	}

	public BigDecimal getTodaysGain() {
		return todaysGain;
	}

	public void setTodaysGain(BigDecimal todaysGain) {
		this.todaysGain = todaysGain;
	}

	public BigDecimal getTodaysGainPercentage() {
		return todaysGainPercentage;
	}

	public void setTodaysGainPercentage(BigDecimal todaysGainPercentage) {
		this.todaysGainPercentage = todaysGainPercentage;
	}

	public BigDecimal getTodaysHigh() {
		return todaysHigh;
	}

	public void setTodaysHigh(BigDecimal todaysHigh) {
		this.todaysHigh = todaysHigh;
	}

	public BigDecimal getTodaysLow() {
		return todaysLow;
	}

	public void setTodaysLow(BigDecimal todaysLow) {
		this.todaysLow = todaysLow;
	}
}