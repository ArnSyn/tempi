package com.syne.innovation.trade.persistence.entity;

import java.util.Map;

import org.bson.Document;

public class CurrentProblem {
	private String intent;
	private Map<String, String> entities;
	private String query;

	public String getIntent() {
		return intent;
	}

	public void setIntent(String intent) {
		this.intent = intent;
	}

	public Map<String, String> getEntities() {
		return entities;
	}

	public void setEntities(Map<String, String> entities) {
		this.entities = entities;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public Document getDocument() {
		Document document = new Document();
		document.append("intent", intent);
		document.append("entities", entities);
		document.append("query", query);
		return document;
	}

	public CurrentProblem getCurrentProblemFromDocument(Document document) {
		if (document != null) {
			this.setIntent((String) document.get("intent"));
			this.setEntities((Map<String, String>) document.get("entities"));
			this.setQuery((String) document.get("query"));
		}
		return this;
	}
}
