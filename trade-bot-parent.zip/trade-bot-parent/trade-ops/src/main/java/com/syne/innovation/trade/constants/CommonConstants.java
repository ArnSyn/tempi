package com.syne.innovation.trade.constants;

public class CommonConstants {
	public static final String CHAT_DETAILS_COLLECTION = "chat_details";
	public static final String FAILED_CHATS_COLLECTION = "failed_chats";
	public static final String TRADE_FLOWS_COLLECTION = "trade_flows";
	public static final String CURRENT_PROBLEM_COLUMN = "currentProblem";
	public static final String SIGNUP_DETAILS_COLLECTION = "profile";
	public static final String RECOMMENDATION_FLOW_COLLECTION = "recommendation_flow";

	public static final String ENTITY_NAME_COMPANY = "company";
	public static final int STATUS_ACTIVE = 1;
	public static final int STATUS_INACTIVE = 0;
	public static final int MAX_RESULTS_TOP_TRADED = 5;

	public static final String BUY_QUEUE_NAME = "buy_queue";
	public static final String SELL_QUEUE_NAME = "sell_queue";
	
	public static final String STOCK_CATEGORY_EQUITY = "equity";
	public static final String STOCK_CATEGORY_CURRENCY = "currency";
	public static final String STOCK_CATEGORY_COMMODITY = "commodity";
}
