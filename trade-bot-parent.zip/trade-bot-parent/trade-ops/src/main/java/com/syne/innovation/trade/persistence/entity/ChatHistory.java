package com.syne.innovation.trade.persistence.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.bson.Document;

public class ChatHistory implements Comparable<ChatHistory>{

	private String query;
	private Date queriedOn;
	private String response;
	private Date respondedOn;
	private String intentName;
	private Map<String,String> entities;
	private Map<String,String> tempEntities;

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public Date getQueriedOn() {
		return queriedOn;
	}

	public void setQueriedOn(Date queriedOn) {
		this.queriedOn = queriedOn;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public Date getRespondedOn() {
		return respondedOn;
	}

	public void setRespondedOn(Date respondedOn) {
		this.respondedOn = respondedOn;
	}

	public String getIntentName() {
		return intentName;
	}

	public void setIntentName(String intentName) {
		this.intentName = intentName;
	}

	public Map<String, String> getEntities() {
		return entities;
	}

	public void setEntities(Map<String, String> entities) {
		this.entities = entities;
	}

	public Map<String, String> getTempEntities() {
		return tempEntities;
	}

	public void setTempEntities(Map<String, String> tempEntities) {
		this.tempEntities = tempEntities;
	}

	public Document getDocument() {
		Document document = new Document();
		document.put("query", query);
		document.put("queriedOn", queriedOn);
		document.put("response", response);
		document.put("respondedOn", respondedOn);
		document.put("intentName", intentName);
		document.put("entities", entities);
		document.put("tempEntities", tempEntities);
		return document;
	}

	public List<ChatHistory> getChatHistoryForDocument(List<Document> documents) {
		List<ChatHistory> chatHistory = new ArrayList<>();
		if (documents != null) {
			for (Document document : documents) {
				ChatHistory history = new ChatHistory();
				history.setIntentName((String) document.get("intentName"));
				history.setEntities((Map<String,String>) document.get("entities"));
				history.setTempEntities((Map<String,String>) document.get("tempEntities"));
				history.setQueriedOn((Date) document.get("queriedOn"));
				history.setQuery((String) document.get("query"));
				history.setRespondedOn((Date) document.get("respondedOn"));
				history.setResponse((String) document.get("response"));
				chatHistory.add(history);
			}
		}
		return chatHistory;
	}

	@Override
	public int compareTo(ChatHistory chatHistory) {
		return (-1)*this.getRespondedOn().compareTo(chatHistory.getRespondedOn());
	}
}
