package com.syne.innovation.trade.persistence.entity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="stock")
public class Stock {
	
	@Id
	@Column(name="StockId")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int stockId;
	
	private String stockName;
	
	private String symbol;
	
	private BigDecimal lastPrice;

	private Date lastUpdatedOn;
	
	private int status;
	
	private String createdBy;
	
	private Date createdOn;
	
	private String updatedBy;
	
	private Date updatedOn;
	
	private String category;

	@OneToMany(fetch = FetchType.EAGER, mappedBy = "stock")
	private List<PortfolioDetails> portfolioDetails = new ArrayList<PortfolioDetails>();
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "stock")
	private List<StockTransaction> stockTransactions = new ArrayList<StockTransaction>();
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "stock")
	private List<WatchListDetails> watchListDetails = new ArrayList<WatchListDetails>();
	
	public int getStockId() {
		return stockId;
	}

	public void setStockId(int stockId) {
		this.stockId = stockId;
	}

	public String getStockName() {
		return stockName;
	}

	public void setStockName(String stockName) {
		this.stockName = stockName;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public BigDecimal getLastPrice() {
		return lastPrice;
	}

	public void setLastPrice(BigDecimal lastPrice) {
		this.lastPrice = lastPrice;
	}

	public Date getLastUpdatedOn() {
		return lastUpdatedOn;
	}

	public void setLastUpdatedOn(Date lastUpdatedOn) {
		this.lastUpdatedOn = lastUpdatedOn;
	}

	public List<PortfolioDetails> getPortfolioDetails() {
		return portfolioDetails;
	}

	public void setPortfolioDetails(List<PortfolioDetails> portfolioDetails) {
		this.portfolioDetails = portfolioDetails;
	}

	public List<StockTransaction> getStockTransactions() {
		return stockTransactions;
	}

	public void setStockTransactions(List<StockTransaction> stockTransactions) {
		this.stockTransactions = stockTransactions;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
	
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public List<WatchListDetails> getWatchListDetails() {
		return watchListDetails;
	}

	public void setWatchListDetails(List<WatchListDetails> watchListDetails) {
		this.watchListDetails = watchListDetails;
	}
	
}
