package com.syne.innovation.trade.vo;

import java.math.BigDecimal;
import java.util.List;

public class VisiblePortfolio {
	
	private BigDecimal totalInvestedValue;
	
	private BigDecimal totalCurrentValue;
	
	private BigDecimal totalChange;
	
	private List<VisiblePortfolioDetails> portfolioDetails;

	public BigDecimal getTotalInvestedValue() {
		return totalInvestedValue;
	}

	public void setTotalInvestedValue(BigDecimal totalInvestedValue) {
		this.totalInvestedValue = totalInvestedValue;
	}

	public BigDecimal getTotalCurrentValue() {
		return totalCurrentValue;
	}

	public void setTotalCurrentValue(BigDecimal totalCurrentValue) {
		this.totalCurrentValue = totalCurrentValue;
	}

	public List<VisiblePortfolioDetails> getPortfolioDetails() {
		return portfolioDetails;
	}

	public void setPortfolioDetails(List<VisiblePortfolioDetails> portfolioDetails) {
		this.portfolioDetails = portfolioDetails;
	}

	public BigDecimal getTotalChange() {
		return totalChange;
	}

	public void setTotalChange(BigDecimal totalChange) {
		this.totalChange = totalChange;
	}
}