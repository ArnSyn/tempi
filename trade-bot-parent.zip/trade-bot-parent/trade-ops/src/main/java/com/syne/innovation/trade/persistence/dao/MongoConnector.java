package com.syne.innovation.trade.persistence.dao;

import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;

/*
 * Provides connection to MongoDB.
 */
@Component
public class MongoConnector {

	@Value("${mongo.host}")
	private String host;

	@Value("${mongo.port}")
	private String port;

	@Value("${mongo.db}")
	private String database;
	
	@Value("${docker.mongo.host}")
	private String dockerMongoHost;
	
	@Value("${docker.mongo.port}")
	private String dockerMongoPort;

	private MongoClient mongo = null;

	/*@PostConstruct*/
	private synchronized void initializeMongoClient() {
		if (mongo == null) {
			System.out.println("Host : "+dockerMongoHost);
			System.out.println("Port : "+dockerMongoPort);
			mongo = new MongoClient(System.getenv(dockerMongoHost), Integer.parseInt(System.getenv(dockerMongoPort)));
			if(mongo == null) {
				System.out.println("Docker Mongo is NULL.. Trying to connect to localDB .....!! ");
				mongo = new MongoClient(host, Integer.parseInt(port));
			}else {
				System.out.println("Successfully Connected to Docker Mongo .....!! ");
			}
		}
	}

	public MongoDatabase getConnection() {
		initializeMongoClient();
		MongoDatabase db = mongo.getDatabase(database);
		return db;
	}

	@PreDestroy
	public void closeConnection() {
		mongo.close();
	}

}
